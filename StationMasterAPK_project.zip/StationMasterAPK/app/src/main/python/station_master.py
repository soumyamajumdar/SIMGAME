#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
STATION MASTER SIMULATOR  -  Howrah (HWH) <-> Kharagpur (KGP) section
=====================================================================
Single-file, standard-library-only HTTP game.

    python station_master.py [HWHKGP_MASTER_SHEET.xlsx] [port]

Then open  http://localhost:8000

Everything (stations, tracks, platforms, loops, signalling/routing options,
train numbers/names/timings/frequency) is read from the Excel workbook at start
up - nothing about the network or the timetable is hard coded in this file.
(In the workbook "Up" = Howrah -> Kharagpur, "Down" = Kharagpur -> Howrah.)
The only constants below come from the game brief: size of the carshed/siding
groups and the Track-1/2/3/4 direction convention.
"""
import sys, os, re, json, time, random, threading, zipfile, datetime, webbrowser
import xml.etree.ElementTree as ET
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

# ----------------------------------------------------------------------------
# constants from the brief
# ----------------------------------------------------------------------------
GROUP_SIZE = {'CARSHED_TRACKS_EMU': 8, 'KTTP_SIDING_TRACKS': 4,
              'GOOD_SIDING_TRACKS': 8, 'CARSHED_TRACKS_EXPRESS': 12}
TRACK_DIR = {'Track 1': 'D', 'Track 2': 'DU', 'Track 3': 'U', 'Track 4': 'U'}
TRACK_TYPE = {'Track 1': 'Down Main', 'Track 2': 'Down/Up Main', 'Track 3': 'Up Main', 'Track 4': 'Up'}

# simulation tuning
F_OUT = 0.86        # outer signal position inside a block section (fraction)
F_APP = 0.30        # automatic stations start routing from here
GAP = 0.12          # min following gap (fraction of section)
HEAD_MIN = 1.3      # minimum headway (min) before next train may enter same line
D_ARR, D_DEP = 0.40, 0.30   # minutes to cross the station area
SPAWN_LEAD = 8.0    # originating rakes appear this many minutes before departure
TERM_DWELL = 3.0    # terminating rake stays on platform this long
GRID_MIN = 1.0

# ----------------------------------------------------------------------------
# minimal xlsx reader (zip + xml) - no third party libs
# ----------------------------------------------------------------------------
NS = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
RNS = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'


def _cref(ref):
    m = re.match(r'([A-Z]+)(\d+)', ref)
    n = 0
    for ch in m.group(1):
        n = n * 26 + ord(ch) - 64
    return n - 1, int(m.group(2)) - 1


def read_xlsx(path):
    z = zipfile.ZipFile(path)
    ss = []
    if 'xl/sharedStrings.xml' in z.namelist():
        for si in ET.fromstring(z.read('xl/sharedStrings.xml')).iter(NS + 'si'):
            ss.append(''.join(t.text or '' for t in si.iter(NS + 't')))
    wb = ET.fromstring(z.read('xl/workbook.xml'))
    rel = {r.get('Id'): r.get('Target') for r in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
    out = []
    for sh in wb.iter(NS + 'sheet'):
        tgt = rel[sh.get(RNS + 'id')].lstrip('/')
        if not tgt.startswith('xl/'):
            tgt = 'xl/' + tgt
        grid, mr, mc = {}, 0, 0
        for c in ET.fromstring(z.read(tgt)).iter(NS + 'c'):
            ci, ri = _cref(c.get('r'))
            t, v, val = c.get('t'), c.find(NS + 'v'), None
            if t == 'inlineStr':
                val = ''.join(x.text or '' for x in c.iter(NS + 't'))
            elif v is not None and v.text is not None:
                if t == 's': val = ss[int(v.text)]
                elif t in ('str', 'e'): val = v.text
                elif t == 'b': val = bool(int(v.text))
                else: val = float(v.text)
            if val is None or (isinstance(val, str) and not val.strip()):
                continue
            grid[(ri, ci)] = val
            mr, mc = max(mr, ri), max(mc, ci)
        out.append((sh.get('name'), [[grid.get((r, c)) for c in range(mc + 1)] for r in range(mr + 1)]))
    return out


# ----------------------------------------------------------------------------
# helpers to normalise names found in the workbook
# ----------------------------------------------------------------------------
DISP = {}


def skey(s):
    m = re.match(r'\s*([A-Za-z]+)', str(s or ''))
    return m.group(1).lower() if m else ''


def ntrack(s):
    s = re.sub(r'\s+', ' ', str(s).strip())
    m = re.match(r'(?i)^(track|loop)\s*(\d+)$', s)
    if m:
        return '%s %s' % (m.group(1).capitalize(), m.group(2))
    s = re.sub(r'(?i)_track$', '', s)
    u = s.upper()
    DISP.setdefault(u, s)
    return u


def disp(t):
    t = DISP.get(t, t)
    return t.split('#')[0]


def cells(v):
    if v is None:
        return []
    return [ntrack(x) for x in re.split(r'[,;]', str(v))
            if x.strip() and x.strip().upper() not in ('NA', 'NONE', 'NO', '-')]


def yes(v):
    return isinstance(v, str) and v.strip().lower().startswith('y')


def mainnum(t):
    m = re.match(r'Track (\d+)$', t or '')
    return int(m.group(1)) if m else None


def is_main(t):
    return mainnum(t) is not None


def valid(d, line, forced=False):
    td = TRACK_DIR.get(line)
    if td is None:
        return True
    return d in td or forced


def hhmm(m, sec=False):
    s = int(round(m * 60))
    h, mm, ss = (s // 3600) % 24, (s // 60) % 60, s % 60
    return '%02d:%02d:%02d' % (h, mm, ss) if sec else '%02d:%02d' % (h, mm)


# ----------------------------------------------------------------------------
# network model built from the workbook
# ----------------------------------------------------------------------------
class Station:
    pass


ST = []        # list of Station
STIDX = {}     # skey -> index
TT = []        # timetable templates
N = 0


def find_sheet(book, *kw):
    for name, grid in book:
        n = name.lower()
        if all(k in n for k in kw):
            return grid
    raise SystemExit('Sheet with keywords %s not found in workbook' % (kw,))


def table(grid):
    hdr = [ntrack(h) if isinstance(h, str) else None for h in grid[0]]
    rows = {skey(r[0]): r for r in grid[1:] if r[0]}
    return hdr, rows


def routing(tab, key):
    hdr, rows = tab
    row, d = rows.get(key), {}
    if row:
        for c in range(1, len(hdr)):
            if hdr[c]:
                lst = cells(row[c])
                if lst:
                    d[hdr[c]] = lst
    return d


def outer(tab, key):
    hdr, rows = tab
    row = rows.get(key)
    res = []
    if row:
        for c in range(1, len(hdr)):
            if hdr[c] and yes(row[c]) and hdr[c] not in res:
                res.append(hdr[c])
    return res


def load_network(book):
    global N
    plat = find_sheet(book, 'platform')
    ph = [str(h).strip() if h else '' for h in plat[0]]
    for r in plat[1:]:
        if r[0]:
            s = Station()
            s.i = len(ST)
            s.raw = re.sub(r'\s+', ' ', str(r[0])).strip()
            s.key = skey(s.raw)
            s.flag = bool(re.search(r'\sF$', s.raw))
            s.name = re.sub(r'\s*Jn\.?$', '', s.raw)
            s.row = r
            ST.append(s)
            STIDX[s.key] = s.i
    N = len(ST)
    hw = table(find_sheet(book, 'incoming', 'howrah'))
    kg = table(find_sheet(book, 'incoming', 'kharagpur'))
    upin = table(find_sheet(book, 'up', 'incoming'))
    upout = table(find_sheet(book, 'up', 'outgoing'))
    dnin = table(find_sheet(book, 'down', 'incoming'))
    dnout = table(find_sheet(book, 'down', 'outgoing'))
    lp = table(find_sheet(book, 'loop'))
    for s in ST:
        k, row = s.key, s.row
        # ---- platform tracks
        items, byp, groups, seen = [], [], [], {}
        for c in range(1, len(ph)):
            v = row[c] if c < len(row) else None
            if v is None:
                continue
            if 'bypass' in ph[c].lower():
                byp = cells(v)
            else:
                t = ntrack(v)
                seen[t] = seen.get(t, 0) + 1
                if t in GROUP_SIZE:
                    continue
                if seen[t] > 1 or t == 'TERM':
                    t = '%s#%s' % (t, ph[c].replace('PF', '').strip())
                    DISP[t] = 'Term_Track'
                items.append((t, ph[c]))
        trk = []
        for t, pf in items:
            trk.append({'id': t, 'pf': pf})
        order = trk[:]
        mains = [x for x in order if is_main(x['id'])]
        if len(mains) > 1 and mainnum(mains[0]['id']) > mainnum(mains[-1]['id']):
            order.reverse()
        for t in byp:
            if t in GROUP_SIZE:
                groups.append(t)
                continue
            x = {'id': t, 'pf': None}
            if is_main(t):
                pos = 0
                n = mainnum(t)
                for j, y in enumerate(order):
                    if is_main(y['id']) and mainnum(y['id']) < n:
                        pos = j + 1
                order.insert(pos, x)
            else:
                order.append(x)
        # main lines present in the outer sections but missing in the platform sheet = bypass tracks
        outer_mains = {l for l in outer(hw, k) + outer(kg, k) if is_main(l)}
        for t in sorted(outer_mains):
            if t not in [y['id'] for y in order]:
                n = mainnum(t)
                pos = 0
                for j, y in enumerate(order):
                    if is_main(y['id']) and mainnum(y['id']) < n:
                        pos = j + 1
                order.insert(pos, {'id': t, 'pf': None})
        idx_m = [j for j, x in enumerate(order) if is_main(x['id'])]
        for j, x in zip(idx_m, sorted([order[j] for j in idx_m], key=lambda x: mainnum(x['id']))):
            order[j] = x
        for x in order:
            t = x['id']
            x['kind'] = ('main' if is_main(t) else 'loop' if t.startswith('Loop') else
                         'term' if t.startswith('TERM') else 'other')
            x['type'] = TRACK_TYPE.get(t, 'Loop' if x['kind'] == 'loop' else
                                       'Terminal' if x['kind'] == 'term' else 'Up/Down')
            x['label'] = disp(t)
        s.tracks = order
        s.tr = {x['id']: x for x in order}
        s.groups = [{'id': g, 'label': disp(g), 'n': GROUP_SIZE[g]} for g in groups]
        s.virtual = not order
        # ---- outer lines each side
        s.hw = outer(hw, k)
        s.kg = outer(kg, k)
        s.up_in, s.up_out = routing(upin, k), routing(upout, k)
        s.dn_in, s.dn_out = routing(dnin, k), routing(dnout, k)
        s.loops = routing(lp, k)
        s.selectable = bool(order)
    # terminals: mirror main tracks on the side that has no data
    for s in ST:
        if s.virtual:
            continue
        if not s.kg:
            s.kg = [l for l in s.hw if is_main(l)]
        if not s.hw:
            s.hw = [l for l in s.kg if is_main(l)]
    # loops connect to main tracks
    for s in ST:
        if s.virtual:
            continue
        for x in s.tracks:
            x['conn'] = [m for m, ls in s.loops.items() if x['id'] in ls and m in s.tr]
        for g in s.groups:
            g['conn'] = [m for m, ls in s.loops.items() if g['id'] in ls and m in s.tr]


def mains(lines):
    return [l for l in lines if is_main(l)]


def lines_between(a, b):
    """main lines in the block section between adjacent stations a,b (b may be N = beyond Kharagpur)."""
    lo, hi = min(a, b), max(a, b)
    A = mains(ST[lo].kg) if 0 <= lo < N else []
    B = mains(ST[hi].hw) if 0 <= hi < N else []
    if A and B:
        return [x for x in B if x in A] or B
    return A or B


def recv_options(st, d, line):
    t1, t2 = (st.up_in, st.dn_in) if d == 'U' else (st.dn_in, st.up_in)
    alts = t1.get(line) or ([] if is_main(line) else t2.get(line, []))
    out = []
    if line in st.tr and valid(d, line):
        out.append(line)
    for a in alts:
        if a in st.tr and a not in out:
            out.append(a)
    if not alts and not is_main(line) and line not in st.tr:      # branch line without routing row: invert the outgoing tables
        for T in st.tr:
            if line in st.up_out.get(T, []) + st.dn_out.get(T, []) and T not in out:
                out.append(T)
    for L in st.loops.get(line, []):
        if L in st.tr and L not in out:
            out.append(L)
    return out


def dep_options(st, d, track):
    far = st.kg if d == 'U' else st.hw
    sheet = st.up_out if d == 'U' else st.dn_out
    kind = st.tr[track]['kind']
    outs = []
    if kind in ('main', 'other') and track in far and valid(d, track):
        outs.append(track)
    for a in sheet.get(track, []):
        if a in far and a not in outs:
            outs.append(a)
    if kind in ('loop', 'term'):
        for M, Ls in st.loops.items():
            if track in Ls and M in far and valid(d, M) and M not in outs:
                outs.append(M)
    return outs


def span(a, b):
    na, nb = mainnum(a), mainnum(b)
    if na and nb:
        return {('main', k) for k in range(min(na, nb), max(na, nb) + 1)}
    if nb: return {('main', nb)}
    if na: return {('main', na)}
    return set()


def arrival_res(st, in_line, track, out, thru):
    res = {('trk', st.i, track)}
    kind = st.tr[track]['kind']
    if kind in ('main', 'other'):
        res |= {(m, st.i, n) for (m, n) in span(in_line, track)}
        if in_line != track and is_main(in_line):          # crossing happens in the throat, not on the platform of the incoming line
            res.discard(('main', st.i, mainnum(in_line)))
    elif in_line and is_main(in_line):
        res.add(('main', st.i, mainnum(in_line)))
    if thru and out:
        res |= dep_res(st, track, out)
    return res


def dep_res(st, track, out):
    res = {('trk', st.i, track)}
    if st.tr[track]['kind'] in ('main', 'other'):
        res |= {(m, st.i, n) for (m, n) in span(track, out)}
    elif is_main(out):
        res.add(('main', st.i, mainnum(out)))
    return res


def stand_res(st, track):
    res = {('trk', st.i, track)}
    if is_main(track):
        res.add(('main', st.i, mainnum(track)))
    return res


# ----------------------------------------------------------------------------
# timetable
# ----------------------------------------------------------------------------
DAYS = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun']


def parse_days(txt):
    t = str(txt or '').lower()
    got = set(DAYS.index(m.group(1)) for m in re.finditer(r'(mon|tue|wed|thu|fri|sat|sun)[a-z]*', t))
    if not got:
        return set(range(7))
    if 'except' in t:
        return set(range(7)) - got
    return got


def classify(name):
    n = name.lower()
    if re.search(r'goods|freight|boxn', n): return 'FREIGHT', 'Freight', 3
    if 'local' in n: return 'LOCAL', 'Passenger', 2
    if re.search(r'pgr|pass|memu|demu', n): return 'PASSENGER', 'Passenger', 1
    return 'EXPRESS', 'Passenger', 0


def tnum(v):
    return round(v * 1440.0, 3) if isinstance(v, float) and 0 <= v < 1.5 else None


class Tmpl:
    entry = exit = src_grp = dest_grp = None


# trains whose name says they go to / come from a branch (brief): keyword -> branch lines
FAMILY = {'amta': ('AMZ_UP', 'AMZ_DOWN'), 'haldia': ('HALDIA_MAIN', 'HALDIA_BYPASS'),
          'digha': ('HALDIA_MAIN', 'HALDIA_BYPASS')}


def pick_branch(stn, name_part, d):
    if skey(name_part) == stn.key:
        return None
    low = name_part.lower()
    for kw, lines in FAMILY.items():
        if kw in low:
            c = [L for L in lines if L in stn.hw or L in stn.kg]
            if len(c) > 1:
                c.sort(key=lambda L: not L.endswith('_UP' if d == 'U' else '_DOWN'))
            if c:
                return c[0]
    return None



def parse_timetable(grid, d):
    hdr, names, freq = grid[0], grid[1], grid[2]
    rows = []
    for r in grid[3:]:
        k = skey(r[1])
        if k in STIDX:
            rows.append((STIDX[k], (str(r[2] or 'd').strip().lower()[:1] or 'd'), r))
    out = []
    for c in range(3, len(hdr)):
        h = hdr[c]
        if h in (None, ''):
            continue
        no = str(int(h)) if isinstance(h, float) else (re.search(r'\d+', str(h)) or [str(h)])[0]
        ent = {}
        for idx, lab, r in rows:
            v = r[c] if c < len(r) else None
            tv = tnum(v)
            if tv is not None:
                ent.setdefault(idx, {})[lab] = tv
        if len(ent) < 2:
            continue
        o = sorted(ent, reverse=(d == 'D'))
        # --- clean the cells: unwrap midnight, drop out-of-order (typo) entries
        lst, shift, prevv = [], 0, None
        for i in o:
            e = ent[i]
            b = e.get('d', e.get('a'))
            if prevv is not None and b + shift < prevv - 720:
                shift += 1440
            e['sh'] = shift
            prevv = b + shift
            lst.append(i)
        changed = True
        while changed and len(lst) > 2:
            changed = False
            val = [ent[i].get('d', ent[i].get('a')) + ent[i]['sh'] for i in lst]
            for j in range(len(lst) - 1):
                if val[j] > val[j + 1] + 0.01:
                    bad = j if (j == 0 or val[j - 1] <= val[j + 1]) else j + 1
                    del lst[bad]
                    changed = True
                    break
        ent = {i: ent[i] for i in lst}
        if len(ent) < 2:
            continue
        o = sorted(ent, reverse=(d == 'D'))
        stp = 1 if d == 'U' else -1
        seq = list(range(o[0], o[-1] + stp, stp))
        nm = re.sub(r'\s+', ' ', str(names[c] or 'Train %s' % no)).strip()
        kind, ptype, prio = classify(nm)
        dw = 2.0 if prio == 0 else 1.0
        arr, dep, stop, prev = {}, {}, {}, None
        for pos, i in enumerate(seq):
            e = ent.get(i)
            if not e:
                stop[i] = False
                continue
            stop[i] = True
            sh = e['sh']
            a, dd = e.get('a'), e.get('d')
            if a is not None and dd is not None:
                arr[i] = a + sh
                dep[i] = dd + sh
                if dep[i] < arr[i]:
                    dep[i] += 1440
                prev = dep[i]
                continue
            t = (a if a is not None else dd) + sh
            if pos == 0:
                dep[i] = t
            elif pos == len(seq) - 1:
                arr[i] = t
            else:
                dep[i] = t
                arr[i] = min(t, max(t - dw, (prev or 0) + 0.3))
            prev = t
        stops_pos = [p for p, i in enumerate(seq) if stop[i]]
        for p, i in enumerate(seq):
            if stop[i]:
                continue
            p0 = max(q for q in stops_pos if q < p)
            p1 = min(q for q in stops_pos if q > p)
            t0 = dep.get(seq[p0], arr.get(seq[p0]))
            t1 = arr.get(seq[p1], dep.get(seq[p1]))
            arr[i] = dep[i] = t0 + (t1 - t0) * (p - p0) / (p1 - p0)
        t = Tmpl()
        t.idx = len(TT) + len(out)
        t.no, t.name, t.dir, t.seq = no, nm, d, seq
        t.arr, t.dep, t.stop = arr, dep, stop
        t.days = parse_days(freq[c])
        t.kind, t.ptype, t.prio = kind, ptype, prio
        t.entry = t.exit = t.src_grp = t.dest_grp = None
        parts = nm.split('-', 1)
        org, dst = parts[0], (parts[1] if len(parts) > 1 else '')
        f0, l0 = seq[0], seq[-1]
        end_first = (f0 == 0) if d == 'U' else (f0 == N - 1)
        end_last = (l0 == N - 1) if d == 'U' else (l0 == 0)
        if not end_first and f0 not in arr and f0 in dep:
            t.entry = pick_branch(ST[f0], org, d)
            if t.entry:
                arr[f0] = dep[f0] - 3.0
        if not end_last and l0 not in dep and l0 in arr:
            t.exit = pick_branch(ST[l0], dst, d)
            if t.exit:
                dep[l0] = arr[l0] + 3.0
        t.cont = seq[-1] in dep and len(seq) > 1 and (seq[-1] in arr)
        t.beyond = d == 'D' and seq[0] == N - 1 and seq[0] in arr
        out.append(t)
    return out


# ----------------------------------------------------------------------------
# freight services (from the brief) - endpoints are resolved from the workbook
# ----------------------------------------------------------------------------
FREIGHT = {
    'ENDS': {'HALDIA': ('line', ('HALDIA_MAIN',), 'Haldia'),
             'LILUAH': ('line', ('LILUAH_BYPASS',), 'Liluah'),
             'CC': ('line', ('CC_UP', 'CC_DOWN'), 'Andul-CC'),
             'HBYPASS': ('line', ('HALDIA_BYPASS',), 'Haldia'),
             'KTTP': ('siding', 'KTTP_SIDING_TRACKS', 'KTPP Siding'),
             'KGP': ('siding', 'GOOD_SIDING_TRACKS', 'Kharagpur')},
    'PAIRS': [('HALDIA', 'KGP'), ('LILUAH', 'KGP'), ('LILUAH', 'KTTP'), ('LILUAH', 'HBYPASS'),
              ('CC', 'KGP'), ('CC', 'KTTP'), ('CC', 'HBYPASS'), ('KTTP', 'KGP'), ('KTTP', 'HBYPASS')],
    'TRIPS': 3, 'SEC': 4.0}


def _flat(tab):
    return [x for v in tab.values() for x in v]


def siding_st(g):
    for s in ST:
        if any(x['id'] == g for x in s.groups):
            return s.i


def f_entry(d, L):
    for s in ST:
        if s.virtual:
            continue
        if d == 'U' and (L in s.up_in or (L in s.hw and L in _flat(s.dn_out))):
            return s.i
        if d == 'D' and (L in s.dn_in or (L in s.kg and L in _flat(s.up_out))):
            return s.i


def f_exit(d, L):
    for s in ST:
        if not s.virtual and L in _flat(s.up_out if d == 'U' else s.dn_out):
            return s.i


def f_end(e, d, src):
    kind, spec, _ = FREIGHT['ENDS'][e]
    if kind == 'siding':
        s = siding_st(spec)
        return (s, None, spec) if s is not None else None
    for L in spec:
        s = (f_entry if src else f_exit)(d, L)
        if s is not None:
            return (s, L, None)


def build_freight():
    out, k, E = [], 0, FREIGHT['ENDS']
    for a, b in FREIGHT['PAIRS']:
        for src, dst in ((a, b), (b, a)):
            for d in 'UD':
                s, e = f_end(src, d, True), f_end(dst, d, False)
                if not s or not e:
                    continue
                (s0, ent, sg), (s1, ex, dg) = s, e
                if (d == 'U' and not s0 < s1) or (d == 'D' and not s0 > s1):
                    continue
                step = 1 if d == 'U' else -1
                seq = list(range(s0, s1 + step, step))
                k += 1
                for trip in range(FREIGHT['TRIPS']):
                    T0 = (k * 97) % 360 + trip * 480 + 20
                    t = Tmpl()
                    t.no = 'G%03d' % (100 + len(out))
                    t.name = '%s-%s Goods' % (E[src][2], E[dst][2])
                    t.dir, t.seq = d, seq
                    t.arr, t.dep, t.stop = {}, {}, {}
                    for p, i in enumerate(seq):
                        tm = T0 + p * FREIGHT['SEC']
                        t.arr[i] = t.dep[i] = tm
                        t.stop[i] = False
                    if sg:
                        t.stop[s0] = True
                        del t.arr[s0]
                    if dg:
                        t.stop[s1] = True
                        del t.dep[s1]
                    t.entry, t.exit, t.src_grp, t.dest_grp = ent, ex, sg, dg
                    t.days = set(range(7))
                    t.kind, t.ptype, t.prio = 'FREIGHT', 'Freight', 3
                    t.cont = bool(ex)
                    t.beyond = False
                    out.append(t)
    return out


# ----------------------------------------------------------------------------
# helpers shared by engine and layout
# ----------------------------------------------------------------------------
def acceptable(b, d, line, stop, frt=False):
    if b < 0 or b >= N or ST[b].virtual:
        return True
    for t in recv_options(ST[b], d, line):
        x = ST[b].tr[t]
        if (x['pf'] or not stop or frt) and (not stop or dep_options_ok(ST[b], d, t)):
            return True
    return False


def dep_options_ok(st, d, t):
    return bool([o for o in dep_options(st, d, t) if is_main(o)])


def side_line(st, line):
    return 'R' if (line in st.hw and line not in st.kg) else 'L'


def side_in(r, st):
    a = r.sec[0]
    if 0 <= a < N:
        return 'R' if a < st.i else 'L'
    if a >= N and is_main(r.line):
        return 'L'
    return side_line(st, r.line)


def side_out(r, st, out):
    if is_main(out):
        return 'L' if r.dir == 'U' else 'R'
    return side_line(st, out)


# --- switch (points) plan: crossovers between main tracks, loop / siding / branch turnouts
SWP = {}


def switch_plan(st):
    n = [0]

    def nid():
        n[0] += 1
        return 'S%d' % n[0]
    xo, xl, lp, ll, ex, exl = {}, [], {}, [], {}, []
    # Up trains enter at the right (Howrah) end and leave at the left; Down the opposite.
    ends = {'R': (st.up_in, st.dn_out), 'L': (st.dn_in, st.up_out)}
    for end, tabs in ends.items():
        seen = set()
        for tab in tabs:
            for a, lst in tab.items():
                for b in lst:
                    if is_main(a) and is_main(b) and a in st.tr and b in st.tr and a != b:
                        key = frozenset((a, b))
                        if key in seen:
                            continue
                        seen.add(key)
                        ids = (nid(), nid())
                        xo[(end, key)] = ids
                        xl.append({'end': end, 'a': a, 'b': b, 'ids': list(ids)})
    names = [x['id'] for x in st.tracks if x['kind'] in ('loop', 'term')] + [g['id'] for g in st.groups]
    for end in ('R', 'L'):
        for t in names:
            lp[(end, t)] = nid()
            ll.append({'end': end, 'track': t, 'id': lp[(end, t)]})
    for line in st.hw + st.kg:
        if not is_main(line) and line not in st.tr and line not in ex:
            ex[line] = nid()
            exl.append({'line': line, 'id': ex[line]})
    return {'xo': xo, 'xl': xl, 'lp': lp, 'll': ll, 'ex': ex, 'exl': exl}


def sw_path(plan, end, a, b, out):
    if not a or not b or a == b:
        return
    if is_main(a) and is_main(b):
        out.update(plan['xo'].get((end, frozenset((a, b))), ()))
        return
    for t in (a, b):
        if (end, t) in plan['lp']:
            out.add(plan['lp'][(end, t)])
        if t in plan['ex']:
            out.add(plan['ex'][t])


# ----------------------------------------------------------------------------
# simulation
# ----------------------------------------------------------------------------
class Run:
    def __init__(s, t, off):
        s.t, s.off = t, off
        s.id = '%d:%d' % (t.idx, off)
        s.no, s.name, s.dir, s.seq = t.no, t.name, t.dir, t.seq
        s.kind, s.ptype, s.prio, s.cont, s.beyond = t.kind, t.ptype, t.prio, t.cont, t.beyond
        s.entry, s.exit, s.src_grp, s.dest_grp = t.entry, t.exit, t.src_grp, t.dest_grp
        sh = off * 1440
        s.arr = {i: v + sh for i, v in t.arr.items()}
        s.dep = {i: v + sh for i, v in t.dep.items()}
        s.stop = t.stop
        s.pos = {i: p for p, i in enumerate(s.seq)}
        s.late = random.choice([0] * 8 + [1, 2, 3, 5, 8])
        first, s.leave_t = s.seq[0], None
        if s.entry:
            s.spawn_t = s.arr[first] - 3.0 + s.late
        elif s.src_grp:
            s.spawn_t = s.dep[first] - 12.0 + s.late
            s.leave_t = s.dep[first] - 3.0 + s.late
        elif t.dir == 'U' and first == 0:
            s.spawn_t = s.dep[first] + s.late
        elif s.beyond:
            s.spawn_t = s.arr[first] - 3.0 + s.late
        else:
            s.spawn_t = s.dep[first] - SPAWN_LEAD + s.late
        last = s.seq[-1]
        s.end_t = max(s.arr.get(last, 0), s.dep.get(last, 0)) + 40
        s.st, s.k, s.sec, s.line, s.f, s.T = 'wait', 0, None, None, 0.0, 4.0
        s.track, s.ph, s.p, s.route, s.dep_route = None, None, 0.0, None, None
        s.delay, s.arr_t, s.i, s.wait_outer, s.grp = 0.0, 0.0, None, 0.0, None
        s.fail_t, s.paf, s.eside = None, set(), 'L'

    def gate(s, i):
        g = s.dep.get(i)
        if g is not None and s.pos[i] == 0:
            g += s.late
        return g


class Sim:
    def __init__(self, default_station):
        self.lock = threading.RLock()
        self.manual = default_station
        self.pa_seq = 0
        self.defer = None
        self.reset()

    # ---- time / lifecycle
    def now_abs(self):
        return (datetime.datetime.now() - self.day0).total_seconds() / 60.0

    def reset(self):
        with self.lock:
            self.day0 = datetime.datetime.combine(datetime.date.today(), datetime.time(0))
            self.runs, self.keys, self.locks = [], set(), {}
            self.events, self.pa, self.gs = [], [], {}
            self.last = time.time()
            now = self.now_abs()
            self.ensure(now)
            self.defer = []
            for r in list(self.runs):
                if r.spawn_t <= now:
                    self.place(r, now)
            defer, self.defer = self.defer, None
            for r, i, fb in defer:                     # running trains first, then trains standing in stations
                if not self.spawn_stand(r, i, now) and fb:
                    self.place_sec(r, *fb)
            self.log(self.manual, 'Simulation reset - traffic restored to timetable position at %s' % hhmm(now, True))

    def ensure(self, now):
        base = int(now // 1440)
        for off in range(base - 1, base + 2):
            wd = (self.day0.date() + datetime.timedelta(days=off)).weekday()
            for t in TT:
                key = (t.idx, off)
                if key in self.keys or wd not in t.days:
                    continue
                r = Run(t, off)
                if r.end_t < now - 5 or r.spawn_t > now + 30:
                    continue
                self.keys.add(key)
                self.runs.append(r)

    # ---- locks
    def free(self, res, r):
        return all(self.locks.get(x, r.id) == r.id for x in res)

    def lock_res(self, res, r):
        for x in res:
            self.locks[x] = r.id

    def release(self, r, keep=None):
        for x in [k for k, v in self.locks.items() if v == r.id]:
            if not keep or x not in keep:
                del self.locks[x]

    def log(self, i, text):
        self.events.append((self.now_abs(), i, text))
        del self.events[:-300]

    # ---- block sections
    def sec_runs(self, a, b, line):
        key = (min(a, b), max(a, b))
        return [o for o in self.runs if o.st == 'sec' and (min(o.sec), max(o.sec)) == key and o.line == line]

    def can_enter(self, a, b, line, d, r=None):
        for o in self.sec_runs(a, b, line):
            if o is r:
                continue
            if o.dir != d:
                return False
            if o.f < min(0.9, HEAD_MIN / max(o.T, 1.0)):
                return False
        return True

    def line_clear(self, b, r=None, line=None):
        if b < 0 or b >= N or ST[b].virtual:
            return True
        if r is not None and r.fail_t is not None and self.now_abs() - r.fail_t > 4.0:
            return True
        d = r.dir if r else None
        if line and TRACK_DIR.get(line) == 'DU' and r is not None:       # shared Down/Up line: no opposing train may hold it at b
            for o in self.runs:
                if o is r or o.dir == d:
                    continue
                if (o.st == 'sec' and o.sec[1] == b and o.line == line) or (o.st == 'stn' and o.i == b and o.track == line):
                    return False
        c = sum(1 for o in self.runs if o is not r and (d is None or o.dir == d) and
                ((o.st == 'stn' and o.i == b and o.ph in ('stand', 'dep')) or
                 (o.st == 'sec' and o.sec[1] == b and o.stop.get(b))))
        return c < max(1, len(ST[b].tracks) - 1)

    def has_leader(self, r):
        return any(o is not r and o.dir == r.dir and o.f > r.f for o in self.sec_runs(r.sec[0], r.sec[1], r.line))

    def next_st(self, r, i):
        p = r.pos[i]
        if p + 1 < len(r.seq):
            return r.seq[p + 1]
        if r.exit:
            return N + 1
        return N if r.cont else None

    def pick_line(self, a, b, d, prio=1, r=None):
        L = [l for l in lines_between(a, b) if valid(d, l)]
        if r is not None:
            g = [l for l in L if acceptable(b, d, l, r.stop.get(b, False), r.prio >= 3)]
            L = g or L
        L.sort(key=lambda l: ((0 if TRACK_DIR.get(l) == d else 1), (mainnum(l) if prio == 0 else -mainnum(l))))
        for l in L:
            if self.can_enter(a, b, l, d):
                return l
        return None

    def secT(self, r, a, b):
        if a in r.dep and b in r.arr:
            return max(0.8, r.arr[b] - r.dep[a] - 0.7)
        return 3.2

    def enter_section(self, r, a, b, line, f):
        self.release(r)
        r.st, r.sec, r.line, r.f = 'sec', (a, b), line, f
        r.route = r.dep_route = r.track = r.ph = None
        r.T = self.secT(r, a, b)
        r.k = r.pos[b] if b in r.pos else len(r.seq)
        r.wait_outer = 0.0

    # ---- departure options that respect the diverting rules of a train
    def dep_opts(self, r, st, track):
        base = dep_options(st, r.dir, track)
        if r.exit and st.i == r.seq[-1]:
            ok = r.exit in base or r.exit in st.up_out.get(track, []) + st.dn_out.get(track, [])
            return [r.exit] if ok else []
        return base

    def dep_ok(self, r, st, track):
        o = self.dep_opts(r, st, track)
        return bool(o) if (r.exit and st.i == r.seq[-1]) else any(is_main(x) for x in o)

    def out_choices(self, r, st, track):
        i = st.i
        if r.exit and i == r.seq[-1]:
            return self.dep_opts(r, st, track)
        nxt = self.next_st(r, i)
        if nxt is None:
            nxt = i + (1 if r.dir == 'U' else -1)
        L = lines_between(i, min(nxt, N))
        ds = dep_options(st, r.dir, track)
        mn = [o for o in ds if is_main(o) and o in L and valid(r.dir, o, True)]
        good = [o for o in mn if acceptable(nxt, r.dir, o, r.stop.get(nxt, False), r.prio >= 3)]
        res = list(good or mn)
        for o in ds:
            if not is_main(o) and o not in res:
                res.append(o)
        return res

    def auto_outs(self, r, st, track):
        return [o for o in self.out_choices(r, st, track) if is_main(o) or o == r.exit]

    # ---- spawning / placement
    def stand_candidates(self, r, st):
        conn = set()
        for g in st.groups:
            if g['id'] == r.src_grp:
                conn = set(g.get('conn', []))
        c = []
        for x in st.tracks:
            if not self.dep_ok(r, st, x['id']):
                continue
            shared = TRACK_DIR.get(x['id']) == 'DU'
            if shared and any(o.st == 'sec' and o.dir != r.dir and o.sec[1] == st.i and o.line == x['id'] for o in self.runs):
                continue
            if r.prio < 3:
                if not x['pf']:
                    continue
                sc = (0 if x['kind'] in ('loop', 'term') else 1) if r.prio >= 2 else (0 if x['kind'] == 'main' else 1)
            else:
                sc = 0 if x['id'] in conn else (1 if not x['pf'] else 2)
            c.append((sc + (0.7 if shared else 0), x['id']))
        return [t for _, t in sorted(c)]

    def spawn_stand(self, r, i, now):
        st = ST[i]
        for t in self.stand_candidates(r, st):
            res = stand_res(st, t)
            if self.free(res, r):
                self.lock_res(res, r)
                r.st, r.i, r.k, r.ph, r.p, r.track = 'stn', i, r.pos[i], 'stand', 0.5, t
                r.route, r.arr_t, r.sec = {'track': t, 'in': None}, now, None
                return True
        return False

    def spawn_siding(self, r, now):
        i = r.seq[0]
        for g in ST[i].groups:
            if g['id'] == r.src_grp:
                slots = self.gs.setdefault((i, g['id']), [None] * g['n'])
                for j, v in enumerate(slots):
                    if v is None:
                        slots[j] = r.no
                        r.st, r.i, r.grp, r.free_t = 'stable', i, (g['id'], j), 1e12
                        return True
        return False

    def place_stand(self, r, i, now, fb=None):
        if getattr(self, 'defer', None) is not None:
            self.defer.append((r, i, fb))
            return True
        if not self.spawn_stand(r, i, now) and fb:
            self.place_sec(r, *fb)
        return True

    def place(self, r, now):
        seq = r.seq
        for k, i in enumerate(seq):
            dp, a = r.dep.get(i), r.arr.get(i)
            if dp is None or now >= dp:
                continue
            if k == 0 and a is None:
                if r.src_grp:
                    if now < r.leave_t:
                        self.spawn_siding(r, now)
                    else:
                        self.place_stand(r, i, now)
                elif i != 0:
                    self.place_stand(r, i, now)
                return
            if a is not None and now >= a and r.stop[i]:
                self.place_stand(r, i, now, (seq[k - 1] if k else (-1 if r.entry else N), i, 0.8))
                return
            if k == 0:
                self.place_sec(r, -1 if r.entry else N, i, min(0.95, max(0.0, 1 - (a - now) / 3.2)))
            else:
                pv = seq[k - 1]
                span_t = max(0.1, a - r.dep[pv])
                self.place_sec(r, pv, i, min(0.95, max(0.0, (now - r.dep[pv]) / span_t)))
            return
        last = seq[-1]
        if r.cont:
            self.place_sec(r, last, N + 1 if r.exit else N, min(0.9, (now - r.dep[last]) / 3.2))
        elif last != 0 and now < r.arr[last] + TERM_DWELL:
            self.place_stand(r, last, now)
        else:
            r.st = 'done'

    def place_sec(self, r, a, b, f):
        d = r.dir
        if a < 0 and r.entry:
            L = [r.entry]
        elif b > N and r.exit:
            L = [r.exit]
        else:
            L = [l for l in lines_between(a, b) if valid(d, l)]
            L.sort(key=lambda l: ((0 if TRACK_DIR.get(l) == d else 1), -mainnum(l)))
        for l in L:
            if all(abs(o.f - f) > GAP / 2 or o.dir != d for o in self.sec_runs(a, b, l)):
                self.enter_section(r, a, b, l, f)
                return True
        if L:
            self.enter_section(r, a, b, L[0], f)
            return True
        return False

    def spawn(self, now):
        for r in self.runs:
            if r.st != 'wait' or now < r.spawn_t:
                continue
            first = r.seq[0]
            if r.entry:
                if self.can_enter(-1, first, r.entry, r.dir):
                    self.enter_section(r, -1, first, r.entry, 0.06)
            elif r.src_grp:
                self.spawn_siding(r, now)
            elif r.dir == 'U' and first == 0:
                nxt = r.seq[1]
                line = self.pick_line(0, nxt, 'U', r.prio, r)
                if line and self.line_clear(nxt, r, line):
                    self.enter_section(r, 0, nxt, line, 0.0)
            elif r.beyond:
                line = self.pick_line(N, first, 'D', r.prio, r)
                if line:
                    self.enter_section(r, N, first, line, 0.05)
            else:
                self.spawn_stand(r, first, now)

    # ---- routing
    def arrival_cands(self, r, st):
        d, i = r.dir, st.i
        stop = r.stop.get(i, False)
        c = []
        for t in recv_options(st, d, r.line):
            x = st.tr[t]
            if stop and not x['pf'] and r.wait_outer < 3 and r.prio < 3:
                continue
            if x['kind'] == 'term' and not stop:
                continue
            if (stop or (r.exit and i == r.seq[-1])) and not self.dep_ok(r, st, t):
                continue
            if stop and r.prio >= 3:
                sc = (0 if not x['pf'] else 1) + (0 if t == r.line else 0.5)
            elif stop:
                if r.prio >= 2:
                    sc = 0 if x['kind'] in ('loop', 'term') else (0.4 if t == r.line else 1)
                else:
                    sc = 0 if t == r.line else (0.6 if x['kind'] in ('loop', 'term') else 1)
            else:
                sc = 0 if t == r.line else (1 if x['kind'] == 'main' else 3)
            if TRACK_DIR.get(t) == 'DU' and stop:
                sc += 0.7
            c.append((sc, t))
        return [t for _, t in sorted(c)]

    def try_route_arrival(self, r, st, track, out=None, auto=False):
        i, d = st.i, r.dir
        thru = not r.stop.get(i, False)
        if auto and thru and out is None:
            for o in self.auto_outs(r, st, track):
                ok, _ = self.try_route_arrival(r, st, track, o, True)
                if ok:
                    return True, ''
            return False, 'No clear outgoing line from %s' % disp(track)
        comb = thru and out is not None
        res = arrival_res(st, r.line, track, out if comb else None, comb)
        if not self.free(res, r):
            bad = [x for x in res if self.locks.get(x, r.id) != r.id]
            return False, 'Route conflict - %s busy/locked' % ', '.join(
                sorted({('Track %d' % x[2]) if x[0] == 'main' else disp(x[2]) for x in bad}))
        if comb:
            nxt = self.next_st(r, i) if is_main(out) else N + 1
            if nxt is None:
                nxt = i + (1 if d == 'U' else -1)
            if not self.can_enter(i, nxt, out, d, r):
                return False, 'Block section ahead on %s is occupied' % out
            if not self.line_clear(nxt, r, out):
                return False, 'Line clear not available from next station'
        self.release(r)
        self.lock_res(res, r)
        r.route = {'track': track, 'in': r.line}
        r.track = track
        r.dep_route = {'out': out} if comb else None
        return True, ''

    def auto_arrival(self, r, st):
        for t in self.arrival_cands(r, st):
            ok, _ = self.try_route_arrival(r, st, t, None, True)
            if ok:
                return True
        return False

    def try_route_departure(self, r, st, out, now):
        i = st.i
        nxt = self.next_st(r, i) if is_main(out) else N + 1
        if nxt is None:
            return False, 'Train terminates here'
        if out not in self.out_choices(r, st, r.track):
            return False, '%s not available from %s' % (out, disp(r.track))
        res = dep_res(st, r.track, out)
        if not self.free(res, r):
            return False, 'Route conflict on outgoing path'
        if not self.can_enter(i, nxt, out, r.dir, r):
            return False, 'Block section on %s occupied - line clear not given' % out
        if not self.line_clear(nxt, r, out):
            return False, 'Next station cannot receive (line clear refused)'
        self.lock_res(res, r)
        r.dep_route = {'out': out}
        return True, ''

    def ready(self, r, now):
        if r.ph == 'arr':
            return True
        g = r.gate(r.i)
        return g is not None and now >= max(g, r.arr_t + 0.5)

    def auto_departure(self, r, st, now):
        outs = self.auto_outs(r, st, r.track)
        outs.sort(key=lambda l: ((0 if (l == r.exit) else 1), (0 if TRACK_DIR.get(l) == r.dir else 1), -(mainnum(l) or 0)))
        for o in outs:
            ok, _ = self.try_route_departure(r, st, o, now)
            if ok:
                return True
        return False

    # ---- tick
    def tick(self):
        with self.lock:
            t = time.time()
            dt = min(t - self.last, 5.0)
            self.last = t
            now = self.now_abs()
            if int(t) % 20 == 0:
                self.ensure(now)
            self.spawn(now)
            self.update_delay(now)
            self.autocontrol(now)
            self.break_deadlocks(now)
            self.move(dt, now)
            self.auto_pa(now)
            self.runs = [r for r in self.runs if r.st != 'done']

    def update_delay(self, now):
        for r in self.runs:
            if r.st == 'sec' and r.sec[0] in r.dep and r.sec[1] in r.arr:
                st_ = r.dep[r.sec[0]] + r.f * (r.arr[r.sec[1]] - r.dep[r.sec[0]])
                r.delay = max(0.0, now - st_)
            elif r.st == 'stn' and r.ph == 'stand':
                dp = r.gate(r.i)
                if dp is not None:
                    r.delay = max(0.0, now - dp) if now >= dp else max(0.0, r.arr_t + 0.5 - dp)
            elif r.st == 'wait':
                r.delay = float(r.late) if now >= r.spawn_t - SPAWN_LEAD else 0.0

    def autocontrol(self, now):
        appr, rdy = {}, {}
        for r in self.runs:
            if r.st == 'sec' and r.route is None and r.f >= F_APP and r.k < len(r.seq):
                appr.setdefault(r.sec[1], []).append(r)
            elif r.st == 'stn' and r.dep_route is None and (
                    (r.ph == 'stand' and r.dep.get(r.i) is not None) or
                    (r.ph == 'arr' and not r.stop.get(r.i, False))):
                rdy.setdefault(r.i, []).append(r)
        for i, lst in appr.items():
            if i == self.manual or i >= N or ST[i].virtual:
                continue
            lst.sort(key=lambda r: (r.prio, -r.f))
            for r in lst:
                if self.has_leader(r):
                    continue
                if self.auto_arrival(r, ST[i]):
                    r.fail_t = None
                elif r.fail_t is None and r.f >= F_OUT - 0.02:
                    r.fail_t = now
        for i, lst in rdy.items():
            if i == self.manual:
                continue
            lst.sort(key=lambda r: r.gate(i) or 0)
            for r in lst:
                if self.ready(r, now):
                    if self.auto_departure(r, ST[i], now):
                        r.fail_t = None
                    elif r.fail_t is None:
                        r.fail_t = now

    def break_deadlocks(self, now):
        """Last resort at automatically controlled stations: a train blocked > 10 min is short-terminated."""
        for r in self.runs:
            if r.fail_t is None or now - r.fail_t < 10.0 or r.st not in ('sec', 'stn'):
                continue
            i = r.sec[1] if r.st == 'sec' else r.i
            if i == self.manual:
                continue
            self.release(r)
            self.log(i if 0 <= i < N else 0, '%s %s cancelled short of destination (traffic block cleared by section controller)' % (r.no, r.name))
            r.st = 'done'

    def move(self, dt, now):
        dm = dt / 60.0
        secs = [r for r in self.runs if r.st == 'sec']
        secs.sort(key=lambda r: -r.f)
        groups = {}
        for r in secs:
            g = groups.setdefault(((min(r.sec), max(r.sec)), r.line), [])
            ld = g[-1] if g else None
            g.append(r)
            sp = (1.0 / r.T) * (1.25 if r.delay > 1.0 else 1.0)
            nf = r.f + sp * dm
            if ld is not None and ld.dir == r.dir:
                nf = min(nf, ld.f - GAP)
            nf = max(nf, r.f)
            a, b = r.sec
            if b >= N or ST[b].virtual:
                if nf >= 1.0:
                    self.release(r)
                    r.st = 'done'
                    continue
            else:
                if r.route is None and nf >= F_OUT:
                    nf = F_OUT
                    r.wait_outer += dm
                if nf >= 1.0 and r.route is not None:
                    r.eside = side_in(r, ST[b])
                    r.st, r.i, r.ph, r.p = 'stn', b, 'arr', 0.0
                    r.k = r.pos[b]
                    r.f = 1.0
                    continue
            r.f = nf
        for r in self.runs:
            if r.st == 'stable' and r.src_grp and r.leave_t is not None and now >= r.leave_t:
                old = r.grp
                if self.spawn_stand(r, r.i, now):
                    self.gs[(r.i, old[0])][old[1]] = None
                    self.log(r.i, '%s %s shunted out of %s' % (r.no, r.name, disp(old[0])))
                continue
            if r.st != 'stn':
                continue
            st = ST[r.i]
            if r.ph == 'arr':
                if not r.stop.get(r.i, False):                     # passing train: waits at starter for clearance
                    r.p = min(1.0 if r.dep_route else 0.6, r.p + dm / 0.5)
                    if r.p >= 1.0:
                        self.leave(r, now)
                else:
                    r.p += dm / D_ARR
                    if r.p >= 0.5:
                        r.p, r.ph, r.arr_t = 0.5, 'stand', now
                        self.release(r, keep=stand_res(st, r.track))
                        self.lock_res(stand_res(st, r.track), r)
                        pf = st.tr[r.track]['pf']
                        self.log(st.i, '%s %s received on %s%s (%s)' % (
                            r.no, r.name, (pf + ' / ') if pf else '', disp(r.track),
                            'on time' if r.delay < 1 else 'late %d min' % round(r.delay)))
            elif r.ph == 'stand':
                if r.dep_route:
                    r.ph = 'dep'
                elif r.dep.get(r.i) is None and now >= r.arr_t + TERM_DWELL:
                    self.terminate(r, now)
            elif r.ph == 'dep':
                r.p += dm / D_DEP
                if r.p >= 1.0:
                    r.p = 1.0
                    self.leave(r, now)
        for r in self.runs:
            if r.st == 'stable' and now > r.free_t:
                self.gs[(r.i, r.grp[0])][r.grp[1]] = None
                r.st = 'done'

    def leave(self, r, now):
        i = r.i
        st = ST[i]
        out = r.dep_route['out']
        if is_main(out):
            nxt = self.next_st(r, i)
            if nxt is None:
                nxt = i + (1 if r.dir == 'U' else -1)
            nxt = min(nxt, N)
        else:
            nxt = N + 1
        if not self.can_enter(i, nxt, out, r.dir, r):
            return
        pf = st.tr[r.track]['pf']
        if not is_main(out):
            self.log(i, '%s %s dispatched via %s' % (r.no, r.name, disp(out)))
        elif not r.stop.get(i, False):
            self.log(i, '%s %s passed through via %s' % (r.no, r.name, disp(r.track)))
        else:
            self.log(i, '%s %s departed from %s%s (%s)' % (
                r.no, r.name, (pf + ' / ') if pf else '', disp(r.track),
                'right time' if r.delay < 1 else 'late %d min' % round(r.delay)))
        self.enter_section(r, i, nxt, out, 0.0)

    def terminate(self, r, now):
        st = ST[r.i]
        self.release(r)
        for g in sorted(st.groups, key=lambda g: g['id'] != r.dest_grp):
            slots = self.gs.setdefault((st.i, g['id']), [None] * g['n'])
            for j, v in enumerate(slots):
                if v is None:
                    slots[j] = r.no
                    r.st, r.grp, r.free_t = 'stable', (g['id'], j), now + 20
                    self.log(st.i, '%s %s terminated - rake shunted to %s' % (r.no, r.name, g['label']))
                    return
        r.st = 'done'

    # ---- manual actions
    def find(self, rid):
        for r in self.runs:
            if r.id == rid:
                return r

    def act_arrival(self, i, rid, track, out=None):
        with self.lock:
            r = self.find(rid)
            if not r or r.st != 'sec' or r.sec[1] != i:
                return False, 'Train is not in the approach section of this station'
            if self.has_leader(r):
                return False, 'Another train is ahead of %s in the block - clear that train first' % r.no
            st = ST[i]
            if track not in recv_options(st, r.dir, r.line):
                return False, '%s cannot be reached from incoming %s' % (disp(track), disp(r.line))
            x = st.tr[track]
            if r.stop.get(i, False) and not x['pf']:
                return False, 'Train has stoppage - %s has no platform' % disp(track)
            old = (r.route, r.track, r.dep_route, {k: v for k, v in self.locks.items() if v == r.id})
            self.release(r)
            r.route = r.dep_route = None
            ok, msg = self.try_route_arrival(r, st, track, None, False)
            if not ok:
                r.route, r.track, r.dep_route = old[0], old[1], old[2]
                for k, v in old[3].items():
                    self.locks[k] = v
                return False, msg
            self.log(i, 'Arrival clearance given to %s -> %s%s' % (
                r.no, (x['pf'] + ' / ') if x['pf'] else '', disp(track)))
            return True, 'Arrival clearance given for %s on %s' % (r.no, disp(track))

    def act_cancel(self, i, rid):
        with self.lock:
            r = self.find(rid)
            if not r or r.st != 'sec' or r.sec[1] != i or not r.route:
                return False, 'Nothing to cancel'
            self.release(r)
            r.route = r.track = r.dep_route = None
            return True, 'Route cancelled for %s' % r.no

    def act_departure(self, i, rid, out):
        with self.lock:
            r = self.find(rid)
            now = self.now_abs()
            if not r:
                return False, 'Unknown train'
            thru = not r.stop.get(i, False)
            ok_stn = r.st == 'stn' and r.i == i and (r.ph == 'stand' or (r.ph == 'arr' and thru))
            ok_pre = r.st == 'sec' and r.sec[1] == i and r.route and thru
            if not (ok_stn or ok_pre):
                return False, 'Train is not ready for departure clearance at this station'
            if r.dep_route:
                return False, 'Departure already cleared'
            if r.ph == 'stand' and not self.ready(r, now):
                return False, 'Not yet time - scheduled departure %s' % hhmm(r.gate(i))
            ok, msg = self.try_route_departure(r, ST[i], out, now)
            if ok:
                self.log(i, 'Departure clearance given to %s via %s' % (r.no, disp(out)))
                return True, 'Departure clearance given for %s via %s' % (r.no, disp(out))
            return False, msg

    # ---- public address
    def pa_text(self, i, r, kind, text=''):
        st = ST[i]
        if kind == 'custom' or not r:
            return text
        pf = None
        if r.route and r.track and ((r.st == 'stn' and r.i == i) or (r.st == 'sec' and r.sec[1] == i)):
            pf = st.tr[r.track]['pf']
        p = ('platform number %s' % pf.replace('PF', '').strip()) if pf else 'the platform'
        base = 'Train number %s, %s' % (r.no, r.name)
        late = int(round(r.delay))
        base_t = r.arr.get(i, r.dep.get(i, 0)) + r.delay
        toward = 'Howrah' if r.dir == 'D' else 'Kharagpur'
        return {
            'approach': 'May I have your attention please. %s, towards %s, is expected at %s at %s%s. %s' % (
                base, toward, st.name, hhmm(base_t), (', running late by %d minutes' % late) if late >= 1 else '',
                'This train will stop here.' if r.stop.get(i) else 'This train will pass through without stopping. Passengers are requested to stay behind the yellow line.'),
            'arrival': 'May I have your attention please. %s, is arriving shortly on %s at %s.' % (base, p, st.name),
            'departure': 'May I have your attention please. %s, is ready to depart from %s shortly.' % (base, p),
            'late': '%s, is running late by %d minutes. The inconvenience is regretted.' % (base, late),
            'pass': '%s, will pass through %s without stopping. Passengers are requested to stay behind the yellow line.' % (base, st.name),
            'change': 'Platform change. %s, will now arrive on %s.' % (base, p),
        }.get(kind, text)

    def pa_add(self, i, msg):
        self.pa_seq += 1
        self.pa.append({'seq': self.pa_seq, 'st': i, 't': hhmm(self.now_abs(), True), 'text': msg})
        del self.pa[:-200]

    def act_announce(self, i, rid, kind, text):
        with self.lock:
            msg = self.pa_text(i, self.find(rid), kind, text)
            if not msg:
                return False, 'Empty announcement'
            self.pa_add(i, msg)
            return True, 'Announcement made'

    def auto_pa(self, now):
        """The public address system announces every approaching train of the controlled station."""
        i = self.manual
        if i < 0 or i >= N or ST[i].virtual:
            return
        for r in self.runs:
            if r.st in ('wait', 'done', 'stable') or i not in r.pos:
                continue
            here = r.st == 'stn' and r.i == i
            if here:
                if r.dep_route and r.stop.get(i) and r.dep.get(i) is not None and ('dep', i) not in r.paf:
                    r.paf.add(('dep', i))
                    self.pa_add(i, self.pa_text(i, r, 'departure'))
                continue
            if r.k > r.pos[i]:
                continue
            eta = r.arr.get(i, r.dep.get(i, 0)) + r.delay
            if eta - now > 10:
                continue
            if ('app', i) not in r.paf:
                r.paf.add(('app', i))
                self.pa_add(i, self.pa_text(i, r, 'approach'))
            if r.st == 'sec' and r.sec[1] == i and r.route and r.stop.get(i):
                k = ('plat', i, r.route['track'])
                if k not in r.paf:
                    kind = 'change' if any(x[0] == 'plat' and x[1] == i for x in r.paf) else 'arrival'
                    r.paf.add(k)
                    self.pa_add(i, self.pa_text(i, r, kind))

    def select(self, i):
        with self.lock:
            self.manual = i
            self.log(i, 'Control transferred to %s station master' % ST[i].name)

    # ---- data for clients
    def pf_label(self, st, t):
        x = st.tr.get(t)
        if not x:
            return disp(t)
        return ('%s | ' % x['pf'] if x['pf'] else '') + disp(t)

    def state(self, i):
        with self.lock:
            now = self.now_abs()
            st = ST[i]
            plan = SWP.get(i)
            occ, resv, trains, sig, rev = {}, set(), [], {}, set()
            for r in self.runs:
                if r.st == 'stn' and r.i == i and r.track:
                    occ[r.track] = r.no
                if r.st == 'sec' and r.sec[1] == i and r.route:
                    resv.add(r.route['track'])
            for r in self.runs:
                lab2 = '%s · %s' % ('FRT' if r.ptype == 'Freight' else 'PASS', r.kind)
                stp = 'STOP' if r.stop.get(i) else 'NO STOP'
                base = {'no': r.no, 'l2': lab2, 'l3': stp, 'id': r.id, 'frt': r.ptype == 'Freight'}
                if r.st == 'sec' and r.sec[1] == i:
                    sd = side_in(r, st)
                    if r.f >= 0.5:
                        x = (r.f - 0.5) / 0.5 * 400
                        base.update(x=x if sd == 'L' else 1400 - x, ids=[r.line], p=None)
                        trains.append(base)
                    if r.route:
                        thru = not r.stop.get(i, False)
                        straight = r.route['track'] == r.line
                        if r.f >= 0.3:
                            sig['OUT|%s|%s' % (sd, r.line)] = (('G' if r.dep_route else 'YY') if straight else 'Y') if thru else ('YY' if straight else 'Y')
                        if r.f >= F_OUT - 0.1:
                            sig['HOME|%s|%s' % (sd, r.line)] = 'G' if (thru and straight and r.dep_route) else 'Y'
                elif r.st == 'sec' and r.sec[0] == i and r.f <= 0.5:
                    b = r.sec[1]
                    if 0 <= b < N:
                        sd = 'R' if b < i else 'L'
                    elif is_main(r.line):
                        sd = 'L' if r.dir == 'U' else 'R'
                    else:
                        sd = side_line(st, r.line)
                    x = r.f / 0.5 * 400
                    base.update(x=400 - x if sd == 'L' else 1000 + x, ids=[r.line], p=None)
                    trains.append(base)
                elif r.st == 'stn' and r.i == i:
                    rt = r.route or {}
                    es = r.eside
                    if r.dep_route:
                        xs = side_out(r, st, r.dep_route['out'])
                    else:
                        xs = 'R' if es == 'L' else 'L'
                    if r.p <= 0.5:
                        dx = 1 if es == 'L' else -1
                    else:
                        dx = 1 if xs == 'R' else -1
                    base.update(x=700 + dx * (r.p - 0.5) * 600, p=r.p,
                                ids=[rt.get('in') or r.track, r.track,
                                     (r.dep_route or {}).get('out') or r.track])
                    base['xs'] = 0
                    trains.append(base)
                    if r.ph == 'arr' and r.p < 0.5 and rt.get('in'):
                        thru = not r.stop.get(i, False)
                        sig['HOME|%s|%s' % (es, rt['in'])] = 'G' if (thru and rt['track'] == rt['in'] and r.dep_route) else 'Y'
                    if r.dep_route:
                        sig['STR|%s|%s' % (xs, r.dep_route['out'])] = 'G'
                # reversed switches
                if plan and r.route and ((r.st == 'sec' and r.sec[1] == i) or (r.st == 'stn' and r.i == i)):
                    es = side_in(r, st) if r.st == 'sec' else r.eside
                    if r.st == 'sec' or r.ph == 'arr':
                        sw_path(plan, es, r.route.get('in'), r.route['track'], rev)
                    if r.dep_route:
                        sw_path(plan, side_out(r, st, r.dep_route['out']), r.route['track'], r.dep_route['out'], rev)
            tstate = {}
            for x in st.tracks:
                t = x['id']
                tstate[t] = ['O', occ[t]] if t in occ else (['R', ''] if t in resv else ['V', ''])
            gs = {g['id']: self.gs.get((i, g['id']), [None] * g['n']) for g in st.groups}
            appr, stand = [], []
            for r in self.runs:
                if r.st == 'sec' and r.sec[1] == i and i < N:
                    stp = r.stop.get(i, False)
                    opts = []
                    for t in recv_options(st, r.dir, r.line):
                        x = st.tr[t]
                        res = arrival_res(st, r.line, t, None, False)
                        opts.append({'id': t, 'label': '%s%s%s' % (
                            (x['pf'] + ' · ') if x['pf'] else '', disp(t), ' (straight)' if t == r.line else ''),
                            'free': self.free(res, r), 'okp': (x['pf'] is not None) or not stp or r.prio >= 3})
                    dep = None
                    if r.route and not stp:
                        dep = {'outs': [{'id': o, 'label': disp(o), 'free': self.free(dep_res(st, r.route['track'], o), r)}
                                        for o in self.out_choices(r, st, r.route['track'])],
                               'cleared': r.dep_route['out'] if r.dep_route else None}
                    eta = r.arr.get(i, r.dep.get(i, now)) + r.delay
                    appr.append({'id': r.id, 'no': r.no, 'name': r.name, 'kind': r.kind, 'ptype': r.ptype,
                                 'stop': stp, 'line': disp(r.line), 'f': round(r.f, 2), 'eta': hhmm(eta),
                                 'delay': int(round(r.delay)), 'opts': opts, 'dep': dep,
                                 'held': r.f >= F_OUT - 0.01 and not r.route,
                                 'route': ({'track': self.pf_label(st, r.route['track']),
                                            'tid': r.route['track']} if r.route else None)})
                elif r.st == 'stn' and r.i == i and (r.ph in ('stand', 'dep') or (r.ph == 'arr' and not r.stop.get(i, False))):
                    thru = not r.stop.get(i, False)
                    outs = self.out_choices(r, st, r.track) if (r.dep.get(i) is not None or thru) else []
                    stand.append({'id': r.id, 'no': r.no, 'name': r.name, 'kind': r.kind,
                                  'track': self.pf_label(st, r.track), 'thru': thru,
                                  'sched': hhmm(r.gate(i)) if r.dep.get(i) is not None and not thru else '--',
                                  'ready': self.ready(r, now) and r.ph in ('stand', 'arr'),
                                  'term': r.dep.get(i) is None and not thru,
                                  'cleared': r.dep_route['out'] if r.dep_route else None,
                                  'delay': int(round(r.delay)),
                                  'outs': [{'id': o, 'label': disp(o),
                                            'free': self.free(dep_res(st, r.track, o), r)} for o in outs]})
            appr.sort(key=lambda a: -a['f'])
            board = []
            for r in self.runs:
                if i not in r.pos or r.st in ('done', 'stable'):
                    continue
                k = r.pos[i]
                if r.st != 'wait' and r.k > k:
                    continue
                base = r.arr.get(i, r.dep.get(i))
                eta = base + r.delay
                at_here = r.st == 'stn' and r.i == i
                if not at_here and (eta - now > 75 or eta - now < -3):
                    continue
                plat = '--'
                if r.route and r.track and ((r.st == 'sec' and r.sec[1] == i) or at_here):
                    x = st.tr[r.track]
                    plat = x['pf'] if x['pf'] else disp(r.track)
                if at_here:
                    status = 'ON PLATFORM' if r.ph == 'stand' else ('ARRIVING' if r.ph == 'arr' else 'DEPARTING')
                elif r.st == 'sec' and r.sec[1] == i and r.f > 0.5:
                    status = 'ARRIVING' if r.stop.get(i) else 'PASSING'
                elif r.delay >= 1:
                    status = 'LATE %d MIN' % round(r.delay)
                else:
                    status = 'ON TIME'
                board.append({'id': r.id, 'no': r.no, 'name': r.name, 'kind': r.kind, 'stop': bool(r.stop.get(i)),
                              'dir': 'TO HOWRAH' if r.dir == 'D' else 'TO KHARAGPUR',
                              'eta': hhmm(eta), 'sched': hhmm(base), 'platform': plat, 'status': status, 'key': eta})
            board.sort(key=lambda b: b['key'])
            mp = []
            for r in self.runs:
                if r.st == 'sec':
                    a, b = r.sec
                    sgn = 1 if r.dir == 'U' else -1
                    if a < 0 or a >= N:
                        pos = b - sgn * (1 - r.f) * 0.7
                    elif b >= N:
                        pos = a + sgn * r.f * 0.7
                    else:
                        pos = a + (b - a) * r.f
                    mp.append({'no': r.no, 'name': r.name, 'kind': r.kind, 'dir': r.dir, 'pos': round(pos, 3),
                               'line': r.line, 'delay': int(round(r.delay)), 'frt': r.ptype == 'Freight'})
                elif r.st == 'stn':
                    mp.append({'no': r.no, 'name': r.name, 'kind': r.kind, 'dir': r.dir, 'pos': r.i,
                               'line': r.track, 'delay': int(round(r.delay)), 'frt': r.ptype == 'Freight'})
            ev = [{'t': hhmm(t, True), 'text': x} for t, s_, x in self.events if s_ == i][-40:]
            pa = [p for p in self.pa if p['st'] == i][-30:]
            return {'clock': hhmm(now, True),
                    'wd': DAYS[(self.day0.date() + datetime.timedelta(days=int(now // 1440))).weekday()].title(),
                    'station': i, 'manual': self.manual, 'trains': trains, 'sig': sig, 'tstate': tstate,
                    'groups': gs, 'appr': appr, 'stand': stand, 'board': board[:30], 'map': mp, 'sw': sorted(rev),
                    'events': ev, 'pa': pa, 'active': len(self.runs)}


# ----------------------------------------------------------------------------
# layout / static data for the browser
# ----------------------------------------------------------------------------
def layout(i):
    st = ST[i]
    plan = SWP[i]

    def sigs(lines, d):
        return [l for l in lines if is_main(l) and valid(d, l)]
    ex_hw = [l for l in st.hw if l not in st.tr and not is_main(l)]
    ex_kg = [l for l in st.kg if l not in st.tr and not is_main(l)]

    def conn(l):
        c = st.up_in.get(l, []) + st.dn_in.get(l, []) + [T for T, v in st.up_out.items() if l in v] + \
            [T for T, v in st.dn_out.items() if l in v]
        return [m for m in c if m in st.tr and is_main(m)]
    # VDU: left = Kharagpur side, right = Howrah side
    return {'i': i, 'name': st.raw, 'flag': st.flag, 'tracks': st.tracks, 'groups': st.groups,
            'hw': st.hw, 'kg': st.kg,
            'ex_hw': [{'id': l, 'label': disp(l), 'sw': plan['ex'][l]} for l in ex_hw],
            'ex_kg': [{'id': l, 'label': disp(l), 'sw': plan['ex'][l]} for l in ex_kg],
            'conn_ex': {l: conn(l) for l in ex_hw + ex_kg},
            'xo': plan['xl'], 'lsw': plan['ll'],
            'sig': {'OUT_L': sigs(st.kg, 'D'), 'HOME_L': [] if st.flag else sigs(st.kg, 'D'), 'STR_L': sigs(st.kg, 'U'),
                    'OUT_R': sigs(st.hw, 'U'), 'HOME_R': [] if st.flag else sigs(st.hw, 'U'), 'STR_R': sigs(st.hw, 'D')}}


def map_layout():
    secs = [lines_between(a, a + 1) for a in range(N - 1)]
    return {'stations': [{'i': s.i, 'name': s.name, 'flag': s.flag, 'sel': s.selectable,
                          'br': [disp(l) for l in (s.hw + s.kg) if not is_main(l) and l not in s.tr][:6]}
                         for s in ST], 'secs': secs}


# ----------------------------------------------------------------------------
# HTTP server
# ----------------------------------------------------------------------------
SIM = None
HTML = ''


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, obj, code=200, ctype='application/json'):
        body = obj.encode('utf-8') if isinstance(obj, str) else json.dumps(obj).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', ctype + '; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        try:
            if u.path == '/':
                return self._send(HTML, ctype='text/html')
            if u.path == '/api/init':
                return self._send({'stations': [{'i': s.i, 'name': s.raw, 'sel': s.selectable} for s in ST],
                                   'manual': SIM.manual, 'map': map_layout()})
            if u.path == '/api/layout':
                return self._send(layout(int(q['st'])))
            if u.path == '/api/state':
                return self._send(SIM.state(int(q['st'])))
        except Exception as e:
            import traceback
            traceback.print_exc()
            return self._send({'error': str(e)}, 500)
        self._send({'error': 'not found'}, 404)

    def do_POST(self):
        n = int(self.headers.get('Content-Length', 0) or 0)
        try:
            d = json.loads(self.rfile.read(n) or b'{}')
            p = urlparse(self.path).path
            if p == '/api/select':
                SIM.select(int(d['st'])); r = (True, 'ok')
            elif p == '/api/arrival':
                r = SIM.act_arrival(int(d['st']), d['run'], d['track'], d.get('out'))
            elif p == '/api/cancel':
                r = SIM.act_cancel(int(d['st']), d['run'])
            elif p == '/api/departure':
                r = SIM.act_departure(int(d['st']), d['run'], d['out'])
            elif p == '/api/announce':
                r = SIM.act_announce(int(d['st']), d.get('run'), d['kind'], d.get('text', ''))
            elif p == '/api/reset':
                SIM.reset(); r = (True, 'Simulation reset')
            else:
                return self._send({'error': 'not found'}, 404)
            self._send({'ok': r[0], 'msg': r[1]})
        except Exception as e:
            import traceback
            traceback.print_exc()
            self._send({'ok': False, 'msg': 'server error: %s' % e}, 500)


def sim_loop():
    while True:
        try:
            SIM.tick()
        except Exception:
            import traceback
            traceback.print_exc()
        time.sleep(0.5)


def build(path):
    book = read_xlsx(path)
    load_network(book)
    for name, grid in book:
        n = name.lower()
        if 'timings' in n and n.startswith('up'):
            TT.extend(parse_timetable(grid, 'U'))
        elif 'timings' in n and n.startswith('down'):
            TT.extend(parse_timetable(grid, 'D'))
    TT.extend(build_freight())
    for j, t in enumerate(TT):
        t.idx = j
    for s in ST:
        if not s.virtual:
            SWP[s.i] = switch_plan(s)


def main():
    global SIM, HTML
    here = os.path.dirname(os.path.abspath(__file__))
    path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(here, 'HWHKGP_MASTER_SHEET.xlsx')
    port = int(sys.argv[2]) if len(sys.argv) > 2 else 8000
    if not os.path.exists(path):
        raise SystemExit('Workbook not found: %s' % path)
    build(path)
    HTML = PAGE
    default = STIDX.get('panskura', next(s.i for s in ST if s.selectable))
    SIM = Sim(default)
    threading.Thread(target=sim_loop, daemon=True).start()
    srv = ThreadingHTTPServer(('0.0.0.0', port), Handler)
    print('Loaded %d stations, %d timetable trains from %s' % (N, len(TT), os.path.basename(path)))
    print('Station Master Simulator running ->  http://localhost:%d   (Ctrl+C to stop)' % port)
    try:
        webbrowser.open('http://localhost:%d' % port)
    except Exception:
        pass
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


PAGE = r'''<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<title>Station Master Simulator - HWH/KGP</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
:root{--bg:#0b1118;--pn:#121b26;--bd:#243447;--tx:#d7e2ee;--mu:#7f93a8;--ac:#ffb000;--ok:#25e06a;--bad:#ff4d4d}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);font:13px/1.35 Segoe UI,Roboto,Arial,sans-serif}
header{display:flex;flex-wrap:wrap;gap:10px;align-items:center;padding:8px 14px;background:#0e2233;border-bottom:2px solid var(--ac);position:sticky;top:0;z-index:5}
header h1{font-size:16px;margin:0;color:var(--ac);letter-spacing:1px}
select,button,input{background:#0d1620;color:var(--tx);border:1px solid #35506b;border-radius:4px;padding:5px 8px;font:inherit}
button{cursor:pointer;background:#17406a}button:hover{background:#1f5a96}button:disabled{opacity:.4;cursor:not-allowed}
button.red{background:#7a1f1f}button.grn{background:#1d6b3a}
#clock{font:600 20px Consolas,monospace;color:var(--ac)}.sp{flex:1}
main{display:grid;grid-template-columns:minmax(0,1fr) 440px;gap:10px;padding:10px}
@media(max-width:1150px){main{grid-template-columns:1fr}}
section{background:var(--pn);border:1px solid var(--bd);border-radius:6px;padding:8px;min-width:0}
h2{margin:0 0 6px;font-size:13px;color:var(--ac);text-transform:uppercase;letter-spacing:.8px}
h3{margin:8px 0 4px;font-size:12px;color:#9cc4ee}
#vduWrap{overflow:auto;max-height:78vh;background:#05080d;border-radius:4px}
.card{border:1px solid var(--bd);border-radius:5px;padding:6px 8px;margin:5px 0;background:#0d1620}
.card.held{border-color:var(--bad)}.card.done{border-color:var(--ok)}
.tag{display:inline-block;padding:0 6px;border-radius:9px;font-size:11px;background:#264b6e;margin-left:3px}
.tag.s{background:#1d6b3a}.tag.n{background:#6b4a1d}.tag.f{background:#7a1f1f}
.muted{color:var(--mu)}.row{display:flex;gap:6px;align-items:center;flex-wrap:wrap;margin-top:4px}
#toast{min-height:22px;padding:3px 8px;border-radius:4px;margin-bottom:5px;font-weight:600}
#toast.ok{background:#123d25;color:#9bf0be}#toast.bad{background:#4a1414;color:#ffb0b0}
table{width:100%;border-collapse:collapse}
#board{background:#000;border:3px solid #333;border-radius:4px}
#board th{background:#1a1a1a;color:#8aa;font-weight:600;padding:3px 5px;text-align:left;font-size:11px}
#board td{padding:3px 5px;font:600 13px Consolas,monospace;color:#ffbf1f;border-top:1px solid #222;white-space:nowrap}
#board td.nm{white-space:normal;color:#ffd56b}#board td.pf{color:#4dff88;text-align:center}
#board tr.at td{color:#ff7070}
#paScreen{background:#001a33;border:2px solid #2a6;border-radius:5px;padding:8px;min-height:70px;font:600 16px Consolas,monospace;color:#7dffb0}
#paLog{max-height:110px;overflow:auto;font-size:12px;margin-top:5px}
#evLog{max-height:130px;overflow:auto;font:12px Consolas,monospace;color:#9fb3c8}
#mapWrap{overflow-x:auto;background:#05080d;border-radius:4px}
.mst{cursor:pointer}.leg span{margin-right:12px}
.full{grid-column:1/-1}
</style></head><body>
<header>
 <h1>🚉 STATION MASTER SIMULATOR · HWH–KGP</h1>
 <label>Station: <select id="stSel"></select></label>
 <button id="rst" class="red" title="Restore all trains to timetable position">⟲ Reset simulation</button>
 <label><input type="checkbox" id="voice" checked> Voice PA</label>
 <span class="sp"></span><span id="wd" class="muted"></span><span id="clock">--:--:--</span>
</header>
<main>
 <section style="grid-column:1/-1"><h2>VDU - <span id="vTitle"></span> <span class="muted" style="text-transform:none">(controlling station - red dots are trains: no · type · stoppage)</span></h2>
  <div id="vduWrap"><svg id="vdu" style="width:100%;height:auto;display:block" viewBox="0 0 1400 400"></svg></div>
  <div class="leg muted" style="margin-top:4px"><span>Left = Kharagpur side · Right = Howrah side</span><span>Switch: <b style="color:#3b82f6">■</b> normal <b style="color:#ffd400">■</b> reverse</span><span>Track: <b style="color:#5e7590">▬</b> vacant</span><span><b style="color:#f4f4f4">▬</b> route set</span><span><b style="color:#ff3b3b">▬</b> occupied</span>
  <span>Signals: outer = 4-aspect (R·Y·G·YY), home = 3-aspect, starter = 2-aspect</span></div>
 </section>
 <section><h2>Action board - traffic routing</h2><div id="toast"></div><div id="act"></div></section>
 <section><h2>Station indicator display</h2>
  <table id="board"><thead><tr><th>TRAIN</th><th>NAME</th><th>TOWARDS</th><th>EXP.</th><th>PF</th><th>STATUS</th></tr></thead><tbody></tbody></table>
  <h2 style="margin-top:10px">Public announcement</h2>
  <div class="row"><select id="paTr" style="max-width:210px"></select>
   <select id="paKind"><option value="arrival">Arriving</option><option value="departure">Departing</option><option value="late">Running late</option><option value="pass">Not stopping / passing</option><option value="change">Platform change</option><option value="custom">Custom text</option></select></div>
  <div class="row"><input id="paTxt" placeholder="custom text (for 'Custom text')" style="flex:1"><button id="paGo" class="grn">📢 Announce</button></div>
  <div id="paScreen">— no announcement —</div><div id="paLog" class="muted"></div>
  <h2 style="margin-top:10px">Station log</h2><div id="evLog"></div>
 </section>
 <section class="full"><h2>Network map - live position of all running trains <span class="muted" style="text-transform:none">(click a station to take control of it)</span></h2>
  <div id="mapWrap"><svg id="map"></svg></div>
  <div class="leg muted"><span><b style="color:#ff5252">●</b> Up (Howrah→Kharagpur)</span><span><b style="color:#ffb74d">●</b> Down (Kharagpur→Howrah)</span><span><b style="color:#4dd0e1">●</b> Freight</span><span>Equal spacing between stations; all tracks of each section drawn</span></div>
 </section>
</main>
<script>
const W=1400,XL=400,XR=1000,RH=46;
let INIT=null,cur=0,LAY=null,GEO=null,S=null,choice={},lastPa=-1,lastAct='',lastPaList='';
const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
async function api(p,b){const r=await fetch(p,b?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)}:{});return r.json();}
function toast(ok,m){const t=$('#toast');t.className=ok?'ok':'bad';t.textContent=m;clearTimeout(toast.h);toast.h=setTimeout(()=>{t.textContent='';t.className=''},6000);}
async function init(){
  INIT=await api('/api/init');
  $('#stSel').innerHTML=INIT.stations.map(s=>`<option value="${s.i}" ${s.sel?'':'disabled'}>${esc(s.name)}${s.sel?'':' (no track data)'}</option>`).join('');
  cur=INIT.manual;$('#stSel').value=cur;
  await loadLayout();buildMap();await poll();setInterval(poll,1000);
}
async function loadLayout(){LAY=await api('/api/layout?st='+cur);GEO=geom(LAY);
  $('#vdu').setAttribute('viewBox','0 0 '+W+' '+GEO.H);$('#vTitle').textContent=LAY.name+(LAY.flag?' (flag station - no home signals)':'');}
async function pick(i){cur=i;$('#stSel').value=i;choice={};lastAct='';await api('/api/select',{st:i});await loadLayout();lastPa=-1;lastPaList='';await poll();
  const g=$('#mapWrap');g.scrollLeft=50+62*i-g.clientWidth/2;}
$('#stSel').onchange=e=>pick(+e.target.value);
$('#rst').onclick=async()=>{if(confirm('Reset the whole simulation to the current timetable position?')){const r=await api('/api/reset',{});choice={};toast(r.ok,r.msg);poll();}};
async function poll(){
  let s;try{s=await api('/api/state?st='+cur);}catch(e){return;}
  if(s.error)return;S=s;
  $('#clock').textContent=s.clock;$('#wd').textContent=s.wd+' · '+s.active+' trains active';
  drawVDU();renderAct();renderBoard();renderPA();renderLog();drawMapTrains();
}
/* ---------------- VDU : left = Kharagpur side, right = Howrah side ---------------- */
function geom(L){const ex=Math.max(L.ex_hw.length,L.ex_kg.length);const y0=80+ex*28;const rowY={};
  L.tracks.forEach((t,k)=>rowY[t.id]=y0+k*RH);let y=y0+(L.tracks.length-1)*RH+46;const gy={};
  L.groups.forEach(g=>{g.h=Math.max(30,g.n*6+16);gy[g.id]=y;y+=g.h+28;});
  const ex2={};const mk=(arr,side)=>arr.forEach((e,k)=>{const m=(L.conn_ex[e.id]||[])[0];ex2[e.id]={side,y:62+k*28,ym:m!=null&&rowY[m]!=null?rowY[m]:y0,sw:e.sw,label:e.label};});
  mk(L.ex_kg,'L');mk(L.ex_hw,'R');
  return{rowY,y0,gy,H:y+8,ex:ex2};}
const tx=(x,y,s,f,z,a,w)=>`<text x="${x}" y="${y}" fill="${f||'#9fb3c8'}" font-size="${z||11}" text-anchor="${a||'start'}" font-weight="${w||400}" font-family="Consolas,monospace">${esc(s)}</text>`;
const ln=(a,b,c,d,col,w)=>`<line x1="${a}" y1="${b}" x2="${c}" y2="${d}" stroke="${col}" stroke-width="${w||3}"/>`;
const tcol=st=>st&&st[0]=='O'?'#ff3b3b':st&&st[0]=='R'?'#f4f4f4':'#5e7590';
function signal(kind,key,x,y){const a=(S.sig&&S.sig[key])||'R';const lamps=kind=='OUT'?['R','Y','G','Y2']:kind=='HOME'?['R','Y','G']:['R','G'];
  const on={R:a=='R',Y:a=='Y'||a=='YY',Y2:a=='YY',G:a=='G'};const col={R:'#ff2d2d',Y:'#ffd400',Y2:'#ffd400',G:'#25e06a'};
  let o=`<g><title>${kind} signal ${key.split('|').slice(1).join(' ')} : ${a}</title><rect x="${x-3}" y="${y-6}" width="${lamps.length*9+3}" height="12" rx="3" fill="#000" stroke="#555"/>`;
  lamps.forEach((l,j)=>{o+=`<circle cx="${x+3+j*9}" cy="${y}" r="3.4" fill="${on[l]?col[l]:'#262626'}"/>`;});return o+'</g>';}
function swm(id,x,y){const r=S.sw&&S.sw.includes(id);return `<g><title>Switch ${id} ${r?'REVERSE':'NORMAL'}</title><rect x="${x-4.5}" y="${y-4.5}" width="9" height="9" fill="${r?'#ffd400':'#3b82f6'}" stroke="#fff" stroke-width=".8"/>${tx(x,y-7,id,r?'#ffd400':'#8fb4ff',8,'middle')}</g>`;}
function connY(t){const R=GEO.rowY,base=R[t.id];const c=(t.conn||[]).filter(m=>R[m]!=null);
  if(c.length)return R[c.reduce((a,b)=>Math.abs(R[a]-base)<=Math.abs(R[b]-base)?a:b)];
  let best=null;LAY.tracks.forEach(x=>{if(x.kind=='main'&&(best==null||Math.abs(R[x.id]-base)<Math.abs(best-base)))best=R[x.id];});return best!=null?best:base;}
function drawVDU(){if(!LAY||!S||!GEO)return;const L=LAY,R=GEO.rowY,T=S.tstate;let o=[];const swp={};
  o.push(`<rect width="${W}" height="${GEO.H}" fill="#05080d"/>`);
  o.push(tx(200,20,'KHARAGPUR SIDE OUTER  (◄ to Kharagpur)','#6fb3ff',13,'middle',700),tx(700,20,'STATION AREA','#ffb000',13,'middle',700),tx(1200,20,'(to Howrah ►)  HOWRAH SIDE OUTER','#6fb3ff',13,'middle',700));
  o.push(`<line x1="${XL}" y1="28" x2="${XL}" y2="${GEO.H}" stroke="#35506b" stroke-dasharray="6 5"/><line x1="${XR}" y1="28" x2="${XR}" y2="${GEO.H}" stroke="#35506b" stroke-dasharray="6 5"/>`);
  Object.entries(GEO.ex).forEach(([id,e])=>{const y=e.y,ym=e.ym;
    if(e.side=='L'){o.push(`<polyline points="0,${y} 290,${y} 392,${ym} ${XL},${ym}" fill="none" stroke="#9aa6bb" stroke-width="3"/>`,tx(6,y-5,e.label,'#cbd5e6',10),signal('OUT','OUT|L|'+id,262,y+14),swm(e.sw,XL,ym));}
    else{o.push(`<polyline points="${W},${y} 1110,${y} 1008,${ym} ${XR},${ym}" fill="none" stroke="#9aa6bb" stroke-width="3"/>`,tx(W-6,y-5,e.label,'#cbd5e6',10,'end'),signal('OUT','OUT|R|'+id,1098,y-14),swm(e.sw,XR,ym));}});
  let lk=0;
  L.tracks.forEach(t=>{const y=R[t.id],st=T[t.id]||['V',''],c=tcol(st),lab=(t.pf?t.pf+' | ':'')+t.label+' | '+t.type+' | '+(st[0]=='O'?'OCCUPIED '+st[1]:st[0]=='R'?'ROUTE SET':'VACANT');
    if(t.kind=='main'||t.kind=='other'){
      if(L.kg.includes(t.id))o.push(ln(0,y,XL,y,'#6f86a3'));if(L.hw.includes(t.id))o.push(ln(XR,y,W,y,'#6f86a3'));
      o.push(ln(XL,y,XR,y,c,4));if(t.pf)o.push(`<rect x="470" y="${y+7}" width="460" height="8" fill="#9fb3c8" opacity=".28"/>`);
      o.push(tx(575,y-9,lab,st[0]=='O'?'#ff8a8a':'#b8c9dc',11,'start',st[0]=='O'?700:400));
    }else{const ym=connY(t),sx=410+(lk%6)*14;lk++;
      o.push(`<polyline points="${sx},${ym} ${sx+90},${y} ${W-sx-90},${y} ${W-sx},${ym}" fill="none" stroke="${c}" stroke-width="4"/>`);
      swp['L|'+t.id]=[sx,ym];swp['R|'+t.id]=[W-sx,ym];
      if(t.pf)o.push(`<rect x="540" y="${y+7}" width="320" height="8" fill="#9fb3c8" opacity=".28"/>`);
      o.push(tx(575,y-9,lab,st[0]=='O'?'#ff8a8a':'#b8c9dc',11,'start',st[0]=='O'?700:400));}});
  L.groups.forEach(g=>{const y=GEO.gy[g.id],occ=(S.groups&&S.groups[g.id])||[];
    const ym=(()=>{const c=(g.conn||[]).filter(m=>R[m]!=null);return c.length?R[c[0]]:GEO.y0;})();
    swp['L|'+g.id]=[440,ym];swp['R|'+g.id]=[960,ym];
    o.push(`<polyline points="440,${ym} 520,${y+8} 540,${y+8}" fill="none" stroke="#5e7590" stroke-width="3"/><polyline points="860,${y+8} 880,${y+8} 960,${ym}" fill="none" stroke="#5e7590" stroke-width="3"/>`);
    o.push(`<rect x="540" y="${y-6}" width="320" height="${g.h}" fill="#0b1520" stroke="#35506b"/>`);
    for(let j=0;j<g.n;j++){const yy=y+6+j*6;o.push(ln(548,yy,852,yy,occ[j]?'#ff3b3b':'#5e7590',3));}
    o.push(tx(550,y-10,g.label+' ('+g.n+' tracks) - '+occ.filter(Boolean).length+' occupied','#b8c9dc',11));
    [528,868].forEach(x=>{o.push(`<rect x="${x-3}" y="${y+g.h/2-12}" width="22" height="12" rx="3" fill="#000" stroke="#555"/><circle cx="${x+3}" cy="${y+g.h/2-6}" r="3.4" fill="#ff2d2d"/><circle cx="${x+12}" cy="${y+g.h/2-6}" r="3.4" fill="#262626"/>`);});});
  // crossovers between main tracks
  const kc={L:0,R:0};
  L.xo.forEach(c=>{if(R[c.a]==null||R[c.b]==null)return;const k=kc[c.end]++,x1=c.end=='L'?412+k*30:W-412-k*30,x2=c.end=='L'?x1+22:x1-22;
    const rv=S.sw&&S.sw.includes(c.ids[0]);
    o.push(ln(x1,R[c.a],x2,R[c.b],rv?'#f4f4f4':'#3f5873',3),swm(c.ids[0],x1,R[c.a]),swm(c.ids[1],x2,R[c.b]));});
  L.lsw.forEach(w=>{const p=swp[w.end+'|'+w.track];if(p)o.push(swm(w.id,p[0],p[1]));});
  const sg=L.sig;
  sg.OUT_L.forEach(l=>R[l]!=null&&o.push(signal('OUT','OUT|L|'+l,262,R[l]+14)));
  sg.HOME_L.forEach(l=>R[l]!=null&&o.push(signal('HOME','HOME|L|'+l,368,R[l]+14)));
  sg.STR_L.forEach(l=>R[l]!=null&&o.push(signal('STR','STR|L|'+l,368,R[l]-14)));
  sg.STR_R.forEach(l=>R[l]!=null&&o.push(signal('STR','STR|R|'+l,1004,R[l]+14)));
  sg.HOME_R.forEach(l=>R[l]!=null&&o.push(signal('HOME','HOME|R|'+l,1004,R[l]-14)));
  sg.OUT_R.forEach(l=>R[l]!=null&&o.push(signal('OUT','OUT|R|'+l,1098,R[l]-14)));
  S.trains.forEach(tr=>{const y=yTrain(tr),x=tr.x;
    o.push(`<g><circle cx="${x}" cy="${y}" r="11" fill="#e31b1b" stroke="#fff" stroke-width="2.5"/>`+
      `<rect x="${x-62}" y="${y-44}" width="124" height="31" rx="3" fill="#000" opacity=".85" stroke="#e31b1b"/>`+
      tx(x,y-30,tr.no,'#fff',13,'middle',700)+tx(x,y-17,tr.l2+' · '+tr.l3,tr.l3=='STOP'?'#7dffb0':'#ffd56b',10,'middle',700)+'</g>');});
  $('#vdu').innerHTML=o.join('');}
function yLine(id,x){const R=GEO.rowY;if(R[id]!=null)return R[id];const e=GEO.ex[id];if(!e)return null;
  if(e.side=='L')return x<=290?e.y:x>=392?e.ym:e.y+(e.ym-e.y)*(x-290)/102;
  return x>=1110?e.y:x<=1008?e.ym:e.y+(e.ym-e.y)*(1110-x)/102;}
function yTrain(tr){const R=GEO.rowY,i=tr.ids;
  if(tr.p==null)return yLine(i[0],tr.x)??GEO.y0;
  const yy=id=>R[id]!=null?R[id]:(GEO.ex[id]?GEO.ex[id].ym:null);
  const b=yy(i[1]);if(b==null)return GEO.y0;const a=yy(i[0])??b,c=yy(i[2])??b,p=tr.p;
  return p<.25?a+(b-a)*(p/.25):p>.75?b+(c-b)*((p-.75)/.25):b;}
/* ---------------- action board ---------------- */
function optHtml(list,sel){return list.map(o=>`<option value="${esc(o.id)}" ${o.id==sel?'selected':''}>${esc(o.label)}${o.free===false?'  ⛔ busy':''}</option>`).join('');}
function depBlock(id,outs,cleared,ready,label){const c=choice[id]=choice[id]||{};
  if(!c.out||!outs.find(o=>o.id==c.out))c.out=((outs.find(o=>o.free)||outs[0])||{}).id;
  if(cleared)return `<div style="color:#7dffb0">✔ Departure cleared via ${esc(cleared)}</div>`;
  return `<div class="row">Dispatch via: <select data-id="${id}" data-k="out">${optHtml(outs,c.out)}</select><button class="grn" data-a="dep" data-id="${id}" ${ready?'':'disabled'}>${ready?label:'Wait - not time'}</button></div>`;}
function renderAct(){const A=S.appr,D=S.stand;let h=`<h3>⬇ ARRIVAL CLEARANCE - all approaching trains (stopping and passing)</h3>`;
  if(!A.length)h+=`<div class="muted">No train in approach.</div>`;
  A.forEach(a=>{const c=choice[a.id]=choice[a.id]||{};const opts=a.opts.filter(o=>o.okp);
    if(!c.track||!opts.find(o=>o.id==c.track))c.track=(a.route&&a.route.tid)||(opts.find(o=>o.free)||opts[0]||{}).id;
    h+=`<div class="card ${a.held?'held':a.route?'done':''}"><b>${a.no}</b> ${esc(a.name)} <span class="tag ${a.ptype=='Freight'?'f':''}">${a.kind}</span><span class="tag ${a.stop?'s':'n'}">${a.stop?'STOPS HERE':'PASSING'}</span>`+
      `<div class="muted">Incoming ${esc(a.line)} · ETA ${a.eta}${a.delay>0?' (+'+a.delay+' min)':''}${a.held?' · <b style="color:#ff8a8a">HELD AT OUTER SIGNAL</b>':''}</div>`+
      (a.route?`<div style="color:#7dffb0">✔ Route set → ${esc(a.route.track)}</div>`:'')+
      `<div class="row">${a.stop?'Receive on':'Pass on'}: <select data-id="${a.id}" data-k="track">${optHtml(opts,c.track)}</select>`+
      `<button class="grn" data-a="arr" data-id="${a.id}">${a.route?'Change track':'Give arrival clearance'}</button>${a.route?`<button class="red" data-a="cancel" data-id="${a.id}">Cancel</button>`:''}</div>`+
      (a.dep?depBlock(a.id,a.dep.outs,a.dep.cleared,true,'Give departure clearance'):'')+'</div>';});
  h+=`<h3>⬆ DEPARTURE CLEARANCE - trains in station area</h3>`;
  if(!D.length)h+=`<div class="muted">No train in station.</div>`;
  D.forEach(d=>{h+=`<div class="card ${d.cleared?'done':''}"><b>${d.no}</b> ${esc(d.name)} <span class="tag">${d.kind}</span>${d.thru?'<span class="tag n">PASSING</span>':''}<div class="muted">On ${esc(d.track)} · ${d.thru?'waiting at starter':d.term?'<b>terminates here</b>':'sched. dep '+d.sched}${d.delay>0?' (+'+d.delay+' min)':''}</div>`;
    if(d.term)h+=`<div class="muted">Rake will be shunted to carshed/siding.</div>`;
    else h+=depBlock(d.id,d.outs,d.cleared,d.ready,'Give departure clearance');
    h+='</div>';});
  if(h!==lastAct){const ae=document.activeElement;if(!(ae&&ae.tagName=='SELECT'&&$('#act').contains(ae))){$('#act').innerHTML=h;lastAct=h;}}}
$('#act').addEventListener('change',e=>{const t=e.target;if(t.dataset.k){(choice[t.dataset.id]=choice[t.dataset.id]||{})[t.dataset.k]=t.value;lastAct='';renderAct();}});
$('#act').addEventListener('click',async e=>{const b=e.target.closest('button');if(!b)return;const id=b.dataset.id,c=choice[id]||{};let r;
  if(b.dataset.a=='arr')r=await api('/api/arrival',{st:cur,run:id,track:c.track});
  else if(b.dataset.a=='cancel')r=await api('/api/cancel',{st:cur,run:id});
  else if(b.dataset.a=='dep')r=await api('/api/departure',{st:cur,run:id,out:c.out});
  if(r){toast(r.ok,r.msg);lastAct='';poll();}});
/* ---------------- indicator + PA ---------------- */
function renderBoard(){$('#board tbody').innerHTML=S.board.length?S.board.map(b=>`<tr class="${b.status=='ON PLATFORM'?'at':''}"><td>${b.no}</td><td class="nm">${esc(b.name)}${b.stop?'':' <span style="color:#888">(non-stop)</span>'}</td><td>${b.dir.replace('TO ','')}</td><td>${b.eta}${b.eta!=b.sched?'<span style="color:#888"> ('+b.sched+')</span>':''}</td><td class="pf">${esc(b.platform)}</td><td>${b.status}</td></tr>`).join(''):'<tr><td colspan=6 style="color:#888">No trains expected</td></tr>';}
function renderPA(){const items=[...S.stand.map(d=>[d.id,d.no+' '+d.name+' (in station)']),...S.board.map(b=>[b.id,b.no+' '+b.name+' ('+b.eta+')'])];
  const seen={},list=items.filter(x=>!seen[x[0]]&&(seen[x[0]]=1));const sig=JSON.stringify(list);
  if(sig!==lastPaList){const v=$('#paTr').value;$('#paTr').innerHTML=list.map(x=>`<option value="${x[0]}">${esc(x[1])}</option>`).join('');if(v)$('#paTr').value=v;lastPaList=sig;}
  const p=S.pa;if(p.length){const l=p[p.length-1];$('#paScreen').textContent='['+l.t+'] '+l.text;
    $('#paLog').innerHTML=p.slice().reverse().map(x=>`<div>[${x.t}] ${esc(x.text)}</div>`).join('');
    if(lastPa<0)lastPa=l.seq;else{const nw=p.filter(x=>x.seq>lastPa);if(nw.length){lastPa=nw[nw.length-1].seq;nw.slice(-2).forEach(x=>speak(x.text));}}}else $('#paScreen').textContent='— no announcement —',$('#paLog').innerHTML='';}
function speak(t){if(!$('#voice').checked||!window.speechSynthesis)return;const u=new SpeechSynthesisUtterance(t.replace(/\d{3,}/g,m=>m.split('').join(' ')));u.lang='en-IN';u.rate=.95;speechSynthesis.speak(u);}
$('#paGo').onclick=async()=>{const k=$('#paKind').value;const r=await api('/api/announce',{st:cur,run:$('#paTr').value||null,kind:k,text:$('#paTxt').value});toast(r.ok,r.msg);if(r.ok&&k=='custom')$('#paTxt').value='';poll();};
function renderLog(){$('#evLog').innerHTML=S.events.slice().reverse().map(e=>`<div>${e.t}  ${esc(e.text)}</div>`).join('');}
/* ---------------- network map ---------------- */
const MX=50,MD=62,MY={'Track 1':74,'Track 2':92,'Track 3':110,'Track 4':128};
function buildMap(){const M=INIT.map;let o=[];const w=MX*2+MD*(M.stations.length-1);$('#map').setAttribute('width',w);$('#map').setAttribute('height',250);
  o.push(`<rect width="${w}" height="250" fill="#05080d"/>`);
  Object.entries(MY).forEach(([k,y])=>o.push(tx(4,y+4,'T'+k.slice(-1),'#6f86a3',10)));
  M.secs.forEach((ls,a)=>ls.forEach(l=>{if(MY[l]!=null)o.push(ln(MX+MD*a,MY[l],MX+MD*(a+1),MY[l],'#4d6785',2));}));
  M.stations.forEach(s=>{const x=MX+MD*s.i;
    o.push(`<g class="mst" data-i="${s.i}"><rect x="${x-3}" y="62" width="6" height="78" fill="${s.flag?'#6f86a3':'#cfd8e3'}"/><text transform="translate(${x+4},56) rotate(-55)" fill="#cfd8e3" font-size="11" font-family="Segoe UI,Arial">${esc(s.name)}</text>`+
      (s.br.length?`<text x="${x}" y="158" text-anchor="middle" fill="#7f8fa6" font-size="8">${esc(s.br.join(','))}</text>`:'')+`<rect class="sel" id="ms${s.i}" x="${x-11}" y="60" width="22" height="82" fill="none" stroke="#ffb000" stroke-width="2" opacity="0"/><rect x="${x-18}" y="40" width="36" height="110" fill="transparent"/></g>`);});
  o.push(`<text x="${MX}" y="176" fill="#7f8fa6" font-size="10">Loops / platform tracks / branch lines of a station are shown on the lower row ▼</text>`);
  o.push('<g id="mapTr"></g>');$('#map').innerHTML=o.join('');
  $('#map').addEventListener('click',e=>{const g=e.target.closest('.mst');if(g)pick(+g.dataset.i);});}
function drawMapTrains(){if(!S||!INIT)return;const g=$('#mapTr');if(!g)return;let o=[];
  document.querySelectorAll('.sel').forEach(r=>r.setAttribute('opacity',r.id=='ms'+cur?1:0));
  S.map.slice().sort((a,b)=>a.pos-b.pos).forEach((t,k)=>{const x=MX+MD*t.pos,y=MY[t.line]!=null?MY[t.line]:150;const c=t.frt?'#4dd0e1':t.dir=='U'?'#ff5252':'#ffb74d';
    o.push(`<g><title>${t.no} ${esc(t.name)} (${t.kind}) ${t.delay>0?'late '+t.delay+' min':'on time'}</title><circle cx="${x}" cy="${y}" r="${t.frt?6:5}" fill="${c}" stroke="#fff" stroke-width="1"/><text x="${x}" y="${y-8-(k%2)*9}" text-anchor="middle" fill="#fff" font-size="9" font-family="Consolas,monospace">${t.no}</text></g>`);});
  g.innerHTML=o.join('');}
init();
</script></body></html>
'''

if __name__ == '__main__':
    main()
