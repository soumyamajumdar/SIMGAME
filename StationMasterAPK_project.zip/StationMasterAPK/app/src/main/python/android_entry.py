"""Starts the unchanged station_master.py simulator on 127.0.0.1 inside the app."""
import threading
from http.server import ThreadingHTTPServer
import station_master as sm

_started = False

def start(xlsx_path, port=8000):
    global _started
    if _started:
        return port
    sm.build(xlsx_path)
    sm.HTML = sm.PAGE
    default = sm.STIDX.get('panskura', next(s.i for s in sm.ST if s.selectable))
    sm.SIM = sm.Sim(default)
    threading.Thread(target=sm.sim_loop, daemon=True).start()
    srv = ThreadingHTTPServer(('127.0.0.1', port), sm.Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    _started = True
    return port
