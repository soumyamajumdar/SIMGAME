# Station Master - Android 15 APK project
Wraps station_master.py (unchanged) + HWHKGP_MASTER_SHEET.xlsx in a WebView app using Chaquopy (embedded Python 3.12). targetSdk/compileSdk 35.

## Build option A - GitHub (no setup)
1. Create a GitHub repo, upload this folder's contents, push to main.
2. Actions tab -> "Build APK" -> download artifact StationMaster-debug-apk -> app-debug.apk.

## Build option B - Android Studio
Open this folder (Ladybug 2024.2+, JDK 17), let Gradle sync, Build > Build APK(s).
Output: app/build/outputs/apk/debug/app-debug.apk

Install: copy the APK to the phone, allow "install unknown apps". Landscape recommended.
